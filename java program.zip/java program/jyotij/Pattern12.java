import java.util.Scanner;
public class Pattern12 {

	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			for(j=1;j<i;j++){
				System.out.print(" ");
			}
			for(j=i;j<=row;j++){
				System.out.print(j + " ");
			}
			System.out.println();
		}
		for(i=row-1;i>=1;i--){
			for(j=1;j<i;j++){
				System.out.print(" ");
			}
			for(j=i;j<=row;j++){
				System.out.print(j + " ");
			}
			System.out.println();
		}

	}

}

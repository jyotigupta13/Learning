import java.util.Scanner;
public class Pattern14 {

	
	public static void main(String[] args) {
		int i,j,num;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row for this pattern : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			if(i%2==0){
				num=0;
				for(j=1;j<=row;j++){
					System.out.print(num);
					num=(num==0)?1:0;
				}
				System.out.println();
			}
			
			else{
				num=1;
				for(j=1;j<=row;j++){
					System.out.print(num);
					num=(num==1)?0:1;
				}
				System.out.println();
				}
			
		}
		
		
		
	}

}

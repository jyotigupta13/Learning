import java.util.Scanner;
public class Pattern4 {

	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter row : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			for(j=row;j>=i;j--){
				System.out.print(j);
			}
			System.out.println();
		}
				

	}

}

import java.util.Scanner;
public class AddBinary {

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first binary number : ");
		int a=sc.nextInt();
		System.out.println("Enter second binary number : ");
		int b=sc.nextInt();
		

	}

}

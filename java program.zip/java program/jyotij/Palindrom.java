import java.util.Scanner;
public class Palindrom {
static int n,sum=0;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number to check palindrom:");
		int a=sc.nextInt();
		int temp=a;
		while(a>0){
	     n=a%10;
	     sum=sum*10+n;
	     a=a/10;
		}
		if(sum==temp){
			System.out.println("palindrom");
		}
		else{
			System.out.println("not palndrom");
		}
		

	}

}

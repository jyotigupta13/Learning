
public class Addition {
static int a=5,b=4,c;
	
	public static void main(String[] args) {
		c=a+b;
		System.out.println("sum is : " + c);

	}

}

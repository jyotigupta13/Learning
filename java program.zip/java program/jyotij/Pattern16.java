import java.util.Scanner;
public class Pattern16 {

	
	public static void main(String[] args) {
		int i,j,count;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			count=1;
			for(j=1;j<=row;j++){
				if(i%2!=0){
					System.out.print(count);
					count=(count==1)?0:1;
				}
			}
		//	System.out.println();
			
			count=0;
			for(j=1;j<=row;j++){
				
				if(i%2==0){
					System.out.print(count);
					count=(count==0)?1:0;
				}
			}
				System.out.println();
			
			
		}
		
	}

}

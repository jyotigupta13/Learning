import java.util.Scanner;
public class Armstrong {
static int sum=0;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number to find Armstrong or not : ");
		int a=sc.nextInt();
		int temp = a;
		while(a>0){
			int n=a%10;
			a=a/10;
			sum=sum+n*n*n;
			
		}
		if(temp==sum){
			System.out.println("Armstrong");
		}
		else{
			System.out.println("not Armstrong");
		}
	}

}

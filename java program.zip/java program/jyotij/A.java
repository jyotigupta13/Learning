
 class Demo {
	 int i=2,j=3;
	 public static void main(String ar[]){
  
	 }
}  
public class A{
	public static void main(String[] args) {
		Demo obj=new Demo();
		int x=obj.i;
		int y=obj.j;
		System.out.println(x*y);

	}

}

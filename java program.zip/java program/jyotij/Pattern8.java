import java.util.Scanner;                        
public class Pattern8 {

	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row for this pattern : ");
		int row=sc.nextInt();
		for(i=row;i>=1;i--){
			for(j=1;j<=i;j++){
			System.out.print(j);	
			}
			System.out.println();
				
		}
		for(i=2;i<=row;i++){
			for(j=1;j<=i;j++){
				System.out.print(j);
			}
			System.out.println();
		}
		

	}

}

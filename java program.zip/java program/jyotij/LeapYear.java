import java.util.Scanner;
public class LeapYear {

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter year : ");
	    int yr=sc.nextInt();
	    boolean isleap=false;
	    if(yr%4==0)
	    	if(yr%100==0)
	    		if(yr%400==0)
	    			isleap=true;
	    		else
	    		    isleap=false;
	    		
	    	else
	    	    isleap=true;
	    	    	
	    else
	    	isleap=false;	
	    
	    
	    if(isleap==true){
	    	   
	    System.out.println(yr + " is leap year");
	    }
	    else
	    System.out.println(yr + " is not leap year");
	}

}

import java.util.Scanner;
public class Pattern3 {

	
	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row for Pattern : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			for(j=1;j<=i;j++){
				System.out.print(i);
			}
			System.out.println();
		}
	}

}

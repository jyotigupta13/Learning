class F{
	F(int a,int b){
		System.out.println("parent");
	}
}
 class B extends F {
   B(){
	  super(10,20);
	  // Super(20);
	   System.out.println("0 child");
   }
   
   B(int a){
	   super(10,20);
	   System.out.println("1 child");
   }
   
	
	public static void main(String[] args) {
		B obj=new B();

	}

}




import java.util.*;
public class ComplexAdd {
static int i;
	static double real1=5,real2=4;
	static double imag1=4,imag2=2;
	public static void main(String[] args) {
		double c=(real1+real2);
		double d=(imag1+imag2);
		System.out.println("first complex no is : 5+4i" );
		System.out.println("second complex no is : 4+2i");
	System.out.println("output is : " + c + "+" + d + "i");
		
		
	}

}

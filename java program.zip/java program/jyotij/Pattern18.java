import java.util.Scanner;
public class Pattern18 {

	
	public static void main(String[] args) {
		int i,j,count=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			//count=i;
			for(j=1;j<=i;j++){
				System.out.print(count + " ");
				count=count+1;
			}
			System.out.println();
		}
		
		
	}

}

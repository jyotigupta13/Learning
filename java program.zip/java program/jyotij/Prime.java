import java.util.Scanner;
public class Prime {
static int i,count=0;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number to check prime or not :");
		int a=sc.nextInt();
		for(i=1;i<=a;i++){
			if(a%i==0){
				count=count+1;
			}
		}
		if(count==2){
			System.out.println("This is prime number");
		}
		else{
			System.out.println("not prime");
		}

	}

}

import java.util.Scanner;
public class Pattern15 {

	
	public static void main(String[] args) {
		int i,j,count;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row for this pattern : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			count=i;
			for(j=1;j<=i;j++){
				System.out.print(count + " ");
		         count=count+row-j;
			}
			System.out.println();
		}

	}

}

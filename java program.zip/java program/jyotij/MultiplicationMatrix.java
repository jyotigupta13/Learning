import java.util.Scanner;
public class MultiplicationMatrix {

	
	public static void main(String[] args) {
		int i,j,k;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of matrix : ");
		int n=sc.nextInt();
		int a[][]=new int[n][n];
		int b[][]=new int[n][n];
		int mul[][]=new int[n][n];
		//value of matrix a entered by user
		System.out.println("Enter a matrix : ");
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				 a[i][j]=sc.nextInt();
			}
		}
		//value of matrix b entered by user
		System.out.println("Enter b matrix : ");
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				b[i][j]=sc.nextInt();
			}
		}
		System.out.println("Matrix a is : ");
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("Matrix b is : ");
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				System.out.print(b[i][j] + " ");
			}
			System.out.println();
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				mul[i][j]=0;
				for(k=0;k<n;k++){
					mul[i][j]=mul[i][j]+(a[i][k]*b[k][j]);
				}
			}
		}
     System.out.println("matrix multiplication of a matrix and b matrix");
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				System.out.print(mul[i][j] + " ");
			}
			System.out.println();
		}
	}

}

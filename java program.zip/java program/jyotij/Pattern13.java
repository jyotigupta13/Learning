import java.util.Scanner;
public class Pattern13 {

	
	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row for this pattern : ");
		int row=sc.nextInt();
		for(i=1;i<=row+1;i++){
			for(j=row;j>=i;j--){
				System.out.print(1);
			}
			for(j=1;j<=i;j++){
			System.out.print(i);
			}
			System.out.println();
		}

		
	}

}

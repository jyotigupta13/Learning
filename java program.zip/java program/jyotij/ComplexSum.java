//adding two complex number in java.
import java.util.*;
public class ComplexSum {
	int real,imag;

	ComplexSum(int real,int imag){
		this.real=real;
		this.imag=imag;
	}
  public static ComplexSum Sum(ComplexSum s1,ComplexSum s2){
	  // initialize temp with real and imaginary value(0,0)
		ComplexSum temp=new ComplexSum(0,0);
		temp.real=s1.real+s2.real;
		temp.imag=s1.imag+s2.imag;
     //returning the output
		return temp;
		
	}
	
	public static void main(String[] args) {
		ComplexSum s1=new ComplexSum(2,4);
		ComplexSum s2=new ComplexSum(3,5);
		ComplexSum temp = Sum(s1,s2);
		
		System.out.println("first complex number is : " + s1.real + "+" + s1.imag + "i");
		System.out.println("second complex number is : " + s2.real + "+" + s2.imag + "i");
		System.out.println("output is : " + temp.real + "+" +temp.imag + "i");
		
	}

}

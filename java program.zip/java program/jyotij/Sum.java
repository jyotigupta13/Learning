import java.util.Scanner;
public class Sum {
static int c;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a : ");
		int a=sc.nextInt();
		System.out.println("Enter b : ");
		int b=sc.nextInt();
		c=a+b;
		System.out.printf("sum of %d and %d is %d",a,b,c);

	}

}

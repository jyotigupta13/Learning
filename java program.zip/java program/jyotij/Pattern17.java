import java.util.Scanner;
public class Pattern17 {

	
	public static void main(String[] args) {
		int i,j,count=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter row : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			
			for(j=1;j<=row;j++){
				if(i==j){
				System.out.print(count);
				count=count+1;
			   }
				else{
					System.out.print(0);
				}
			}
			System.out.println();
		}
		
		
	}

}

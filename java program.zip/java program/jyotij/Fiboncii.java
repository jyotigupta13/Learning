import java.util.Scanner;
public class Fiboncii {
static int t1=0,t2=1,sum=0,i;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter range for fiboncii series upto:");
        int a=sc.nextInt();
        for(i=1;i<=a;i++){
        System.out.print(t1 + " ");
        sum=t1+t2;
        t1=t2;
        t2=sum;
        }
        
	}

}

import java.util.Scanner;
public class Pattern11 {

	
	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row : ");
		int row=sc.nextInt();
		for(i=1;i<=row;i++){
			for(j=1;j<=i;j++){
				if(j%2==0){
					System.out.print(0);
				}
				else{
					System.out.print(1);
				}
			}
			System.out.println();
		}
		
	}

}

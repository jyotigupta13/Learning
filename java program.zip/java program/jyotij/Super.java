
class E{
	E(){
		System.out.println("parent");
	}
}
 class Super extends E {
   Super(){
	  // super(10,20);
	   this(20);
	   System.out.println("0 child");
   }
   
   Super(int a){
	   System.out.println("1 child");
   }
   
	
	public static void main(String[] args) {
		Super obj=new Super();

	}

}

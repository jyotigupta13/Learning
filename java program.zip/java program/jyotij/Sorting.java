import java.util.Scanner;
public class Sorting {

	
	public static void main(String[] args) {
		int i,j,temp;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length of an array : ");
		int length=sc.nextInt();
		int arr[]=new int[length]; 
		System.out.println("Enter value of an array : ");
		for(i=0;i<length;i++){
		 arr[i]=sc.nextInt();
		}
		System.out.print("Unsorted array are : {");
		for(i=0;i<length;i++){
			System.out.print(arr[i] + "  ");
		}
		System.out.println("}");
		
		System.out.print("Sorted array are : {");
		for(i=0;i<length;i++){
			for(j=i;j>0;j--){
				if(arr[j]<arr[j-1]){
					temp=arr[j];
					arr[j]=arr[j-1];
					arr[j-1]=temp;
				}
			}
		}
		for(i=0;i<length;i++){
		System.out.print(arr[i] + " ");
		}
		System.out.print("}");
	}

}

import java.util.Scanner;
public class StrongNo {

	public static void main(String[] args) {
		int a,fact=1,i,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no : ");
		int n=sc.nextInt();
		int temp=n;
		while(n>0) {
			a=n%10;
			fact=1;
			for(i=a;i>=1;i--) {
			fact=fact*i;
			}
		//	System.out.println(fact);
			sum=sum+fact;
			n=n/10;
		}
		if(temp==sum) {
		System.out.println("strong no");
		}
		else {
			System.out.println("not strong");
			
		}
	}

}

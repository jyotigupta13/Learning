import java.util.Scanner;
public class SumOfAP {

	public static void main(String[] args) {
		int i,sum=0,term;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter n, " + "a and " + "value of d is :");
		int n=sc.nextInt(), a=sc.nextInt(), d=sc.nextInt();
		 sum=(n * (2 * a) + (n-1)*d)/2;
        System.out.println(("sum is : " + sum));
        for(i=0;i<=n;i++) {
        	term=a+i*d;
        	System.out.print(term + " + ");
        }
	}

}

import java.util.Scanner;
public class PrintNumber {
static int i=1;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("number from 1 to 100 : ");
		Number();

	}
	static void Number(){
		while(i<=100) {
		System.out.println(i);
		i++;
		Number();
		}
	}

}

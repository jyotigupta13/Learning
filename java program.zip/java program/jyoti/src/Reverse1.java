import java.util.Scanner;
public class Reverse1 {

	public static void main(String[] args) {
		String reverse="";
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine(); 
		System.out.println("enter your string = " + name);
		int length=name.length();
		for(int i= length-1; i>=0; i--) {
			 reverse=reverse + name.charAt(i);
			
			
		}
		System.out.println("reverse string = " + reverse);

	}

}
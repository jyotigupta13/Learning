import java.util.Scanner;

public class Prime2 {

	public static void main(String[] args) {
		int i, j, count = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number : ");
		int n = sc.nextInt();
		for (i = 2; i < n; i++) {
			count=0;
			for (j = 2; j < i; j++) {
				if (i % j == 0) {
					count++;
					break;
				}
			}
			if (count == 0) {
				System.out.println("prime no is : " + i);

			}
		}
	}

}

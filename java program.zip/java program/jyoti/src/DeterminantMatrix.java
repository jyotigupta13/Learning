import java.util.Scanner;
public class DeterminantMatrix {

	public static void main(String[] args) {
		int i,j,a,b,c;
		Scanner sc=new Scanner(System.in);
		//System.out.println("Enter size of matrix : ");
        //int size=sc.nextInt();
        int m[][]=new int[3][3];
        System.out.println("Enter element in matrix : ");
        for(i=0;i<3;i++) {
        	for(j=0;j<3;j++) {
        		m[i][j]=sc.nextInt();
        		
        	}
        	
        }
        System.out.println("Matrix a is : ");
        for(i=0;i<3;i++) {
        	for(j=0;j<3;j++) {
        		System.out.print(m[i][j] + " ");
        	}
        	System.out.println();
        }
        a=(m[0][0] * (m[1][1]*m[2][2] - m[1][2]*m[2][1]));
        b=(m[0][1] * (m[1][0]*m[2][2] - m[1][2]*m[2][0]));
        c=(m[0][2] * (m[1][0]*m[2][1] - m[1][1]*m[2][0]));
       int  determinant=a-b+c;
       System.out.println("determinant : " + determinant);
        
	}

}

import java.util.Scanner;
public class FibonciiRecur {
	static int t1=0,t2=1,count=10,sum;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print(t1 + " " + t2);
		fiboncii(count-2);
		System.out.println("");

	}
	static void fiboncii(int count){
		if(count>0) {
			sum=t1+t2;
			System.out.print(" " + sum);
			t1=t2;
			t2=sum;
			fiboncii(count-1);
		}
	}

}


public class Piramid8 {

	public static void main(String[] args) {
		int i,j,row=5,k=0,num=0;
		for(i=1;i<=row;i++) {
			for(j=row-1;j>=i;j--) {
				System.out.print(" ");
			}
			for(k=1;k<=i;++k) {
				System.out.print(++num);
			}
			for(k=1;k<i;++k) {
				System.out.print(--num);
			}
			System.out.println();
		}
	}

}

import java.util.Scanner;
public class BreakNo {

	public static void main(String[] args) {
		int count=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		int i=n;
		while(i>0) {
			i=i/10;
			count++;
		}
		while(n>0) {
		int a=n%10;
		System.out.println("at " + count + " position : " + a);
		n=n/10;
		count--;
		}  
	}

}

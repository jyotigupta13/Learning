import java.util.Scanner;
public class QuadraticEq {

	public static void main(String[] args) {
		int x;
		double result;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter value of a :");
        double a=sc.nextDouble();
        System.out.println("Enter value of b : ");
        double b=sc.nextDouble();
        System.out.println("Enter value of c : ");
        double c=sc.nextDouble();
        result=(b*b)-(4*a*c);
        if(result>0) {
        	double r1=(-b+Math.pow(result, 0.5))/(2*a);
        	double r2=(-b-Math.pow(result, 0.5))/(2*a);
        	System.out.printf("root is : %.02f and %.02f",r1,r2);
        	
        }
        else if(result==0) {
        	double r1=((-b)/(2*a));
        	System.out.println("root is : " + r1);
        }
        else {
        	double realPart=-b/(2*a);
        	double imaginaryPart=(Math.sqrt(-result))/(2*a);
        //	System.out.println(realPart+imaginaryPart);
        	System.out.format("root1 = %.2f+%.2fi and root2 = %.2f-%.2fi ",realPart,imaginaryPart,realPart,imaginaryPart);
        }
        
        
	}

}

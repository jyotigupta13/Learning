import java.util.Scanner;
public class Swap1 {

	public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   String a=sc.nextLine();
	   String b=sc.nextLine();
	   int x=Integer.parseInt(a);
	   int y=Integer.parseInt(b);
	   int z;
	   System.out.println("before swap\n a=" + a);
	   System.out.println(" b=" + b);
       z=x;
       x=y;
       y=z;
       System.out.println("After swap\n a=" + x);
       System.out.println("b=" + y);
		

	}

}

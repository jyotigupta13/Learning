import java.util.Scanner;
public class CubeSum {

	public static void main(String[] args) {
		int i;
		double sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter range : ");
		int n=sc.nextInt();
		for(i=1;i<=n;i++) {
			sum=sum+Math.pow(i,3);
			
		}
		System.out.println("sum of cube : " + sum);

	}

}

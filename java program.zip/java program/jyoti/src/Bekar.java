import java.util.Scanner;
public class Bekar {
static int temp,number,sum=0;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no:");
		int n=sc.nextInt();
		temp=n;
		while(n>0){
			number=n%10;
			sum=sum*10+number;
			n=n/10;
		}
		if(temp==sum){
			System.out.println("palindrom");
		}
		else{
			System.out.println("Not palindrom");
		}

	}

}

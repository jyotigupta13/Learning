import java.util.*;
public class B {
static int i,j,k,m;
	
	public static void main(String[] args) {
		for(i=1;i<=5;i++){
			for(j=5;j>i;j--){
				System.out.print(" ");
			}
			for(k=1;k<=i;k++){
				System.out.print("*");
			}
			for(m=i-1;m>=1;m--){
				System.out.print("*");
			}
			System.out.println();
		}

	}

}

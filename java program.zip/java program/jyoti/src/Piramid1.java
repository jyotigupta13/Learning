
public class Piramid1 {
	public static void main(String[] args) {  
		int term=6;  
		
		for (int i = 1; i <= term; i++) {
			for (int j = term; j >= i; j--) {
				System.out.print("* ");
			}
			System.out.println();// new line
		}
		   
//		for(int i=0;i<term;i++) {
//			for(int j=1;j<=term-i;j++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
		
	
		}  
	
}

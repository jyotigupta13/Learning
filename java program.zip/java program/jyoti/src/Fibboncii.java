import java.util.Scanner;
public class Fibboncii {

	public static void main(String[] args) {
		int t1=0,t2=1,sum;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter range upto : ");
		int n=sc.nextInt();
		for(int i=1;i<=n;i++) {
		System.out.print(t1 + "+");
        sum=t1+t2;
        t1=t2;
        t2=sum;
		}
	}

}

import java.util.Scanner;
public class Printint {

	public static void main(String[] args) {
		int i=1,count=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		for(i=2;i<n;i++) {
			if(n%i==0) {
				count=1;
				break;
			}
		}
			if(count==0) {
				System.out.println(n + " is prime number" );
				double a=Math.sqrt(n);
				System.out.println("square root of " + n + " is " + a);
				System.out.printf("square root upto two position: " + " %.02f",a );
			}
			else {
				System.out.println(n + " is not prime number");
			}
		}
         
	

}

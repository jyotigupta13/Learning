import java.util.Scanner;
public class BinaryConvert {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter decimal number : ");
		int n=sc.nextInt();
		System.out.println("binary conversion is : ");
		System.out.println(Integer.toBinaryString(n));

	}

}

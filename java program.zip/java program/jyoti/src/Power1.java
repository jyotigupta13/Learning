import java.util.Scanner;
public class Power1  {

	public static void main(String[] args) {
		int i,result=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter base : ");
		int base=sc.nextInt();
		System.out.println("Enter exponent : ");
		int exp=sc.nextInt();
		if(base>=1 && exp==0) {
			result=1;
		}
		else if(base==0 && exp>=1) {
			result=0;
		}
		else {
        for(i=1;i<=exp;i++) {
        	result=result*base;
        }
	      }
        System.out.println("result of power:\n" + base + "^" + exp + " : " + result);



	}

}
 
import java.util.Scanner;
public class Swap3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in) ;
		System.out.println("enter first no:");
		int a=sc.nextInt();
		System.out.println("Enter second no :");
		int b=sc.nextInt();
		System.out.println("Before swap : \na = " + a + "\nb = " + b);
			a=a+b;
			b=a-b;
			a=a-b;
			System.out.println("After swap : \na= "  + a + "\nb=" + b );
		

	}

}

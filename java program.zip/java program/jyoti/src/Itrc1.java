import java.util.*;
public class Itrc1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Student s1=new Student(20,"jyoti",21);
       Student s2=new Student(21,"vandana",22);
       ArrayList<Student> al=new ArrayList<Student>();
       al.add(s1);
       al.add(s2);
       Iterator itr=al.iterator();
       while(itr.hasNext()) {
    	   Student str=(Student)itr.next();
    	   System.out.println(str.age+" "+str.name+" "+str.rollno);
    	   
       }
       for(Student str:al) 
    	System.out.println(str.age);   
       
	}

}


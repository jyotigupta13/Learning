import java.util.Scanner;
public class SumOfDigitRec {
static int n,sum=0,i;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int num=sc.nextInt();
		sum(num);
		System.out.println("sum is : " + sum);

	}
	static void sum(int num) {
		if(num>0) {
		n=num%10;
		sum=sum+n;
		num=num/10;
		sum(num);
		}
		
	}
	

}

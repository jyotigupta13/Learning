import java.util.Scanner;
public class PrimeR {

	public static void main(String[] args) {
		int i,j,sum=0,num,count=0; 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter lower bound of range no");
		int a=sc.nextInt();
        System.out.println("Enter upper bound of the range");
        int z=sc.nextInt();
        System.out.println("prime no between the range " + a + " and " + z + " is : ");
        for(i=a;i<z;i++) {
        	for(j=2;j<i;j++) {
         if(i%j==0) {
        	 count=0;
        	 break;
         }
         else {
        	 count=1;
         }
        	 
         }
        	if(count==1) {
        		System.out.println(i);
        	}
        
        	/*if(count==1) {
        		sum=sum+i;
        		System.out.println("\n" + sum);
        	}*/
        	
        } 
        //sum=sum+i;
    	//System.out.println("sum of prime no is : " + sum);
	}

}

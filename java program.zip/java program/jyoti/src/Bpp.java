
public class Bpp {

	
	public static void main(String[] args) {
		String info = "";
		info += " my name jy";
		info +=" ";
		info += "builder";
		
		System.out.println(info);
		
		StringBuilder sb = new StringBuilder("");
		sb.append("sue");
		sb.append(" ");
		sb.append("lion");
		System.out.println(sb.toString());
		
		
		StringBuilder s = new StringBuilder("");
		s.append("Roger")
        .append(" ")
         .append("hello");
         System.out.println(s.toString());
         
         System.out.printf("Total cost %-10d; quantity is %dn",5,120);
         for(int i=0; i<20;i++){
        	 System.out.printf("%-2d: %sn",i,"here is some text");
         }
         System.out.printf("Total value : %.2fn",5.6874);
         
         System.out.printf("Total value : %-6.1fn",343.23423);
         
         
	}

}


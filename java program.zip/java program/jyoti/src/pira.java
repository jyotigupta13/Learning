
public class pira {
static int i,j,k;
	
	public static void main(String[] args) {
		for(i=1;i<=7;i++){
			for(j=1;j<=i;j++){
				System.out.print(" ");
			}
			for(k=i;k<=7;k++){
				System.out.print(k + " ");
			}
			System.out.println();
			
		}
		for(i=6;i>=1;i--){
			for(j=1;j<=i;j++){
				System.out.print(" ");
			}
				for(k=i;k<=7;k++){
					System.out.print(k + " ");
				}
			System.out.println();
		}

	}

}

import java.util.Scanner;
public class Armstrong {

	public static void main(String[] args) {
		int a,sum=0,temp;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
	    int n=sc.nextInt();
	    temp=n;
        while(n>0) {
        	a=n%10;
        	n=n/10;
        	sum=sum+a*a*a;
        }
        if(temp==sum) {
        System.out.println(temp + " is Armstrong number");
        }
        else {
        	System.out.println("not armstrong");
        }
	}

}

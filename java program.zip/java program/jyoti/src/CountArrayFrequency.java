import java.util.Scanner;
public class CountArrayFrequency {

	public static void main(String[] args) {
		int i,list=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		
		//System.out.println("Enter array size : ");
		//int size=sc.nextInt();
		int a[]=new int[10];
		//System.out.println("Elements are : ");
		while(n>0) {
			int rem=n%10;
		    a[rem]++;
		   
			n=n/10;
		}
		System.out.println("-------------------------");
		System.out.println("Element    |    Frequency");
		for(i=0;i<a.length;i++) {
			int count=a[i];
			if(count!=0) {
				System.out.print(i + "\t" + "\t" + count );
			}
			System.out.println();
		}
		
		

	}

}

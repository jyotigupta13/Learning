
public class Array1 {

	public static void main(String[] args) {
		
		int[] a= {2,6,4,5,4,3};
	    //  a[0]=2;
		// a[1]=5;
		// a[2]=3;
		int max=a[0];
        for(int i=1; i<a.length ;i++) {
		if(max < a[i]) {
			max=a[i];
		  }
		}
        System.out.println(max);
	}

}

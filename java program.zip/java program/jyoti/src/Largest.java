import java.util.Scanner;
public class Largest {

	public static void main(String[] args) {
		int result,x,big;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		int a=sc.nextInt();
		System.out.println("Enter second number");
        int b=sc.nextInt();
        System.out.println("Enter third number");
        int c=sc.nextInt();
        
        x= (a>b)?a:b; 
        result=	(x>c)?x:c;
        big=(a>b)?(a>c?a:c):(b>c?b:c);
        System.out.println("big : " + big);
        System.out.println("largest : " + result);
	
	}

}

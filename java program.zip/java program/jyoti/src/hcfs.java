import java.util.Scanner;
public class hcfs {

	
	public static void main(String[] args) {
		int hcf=0,lcm;
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		for(int i=1;i<=a && i<=b ;i++){
			if(a%i==0 && b%i==0){
				 hcf=i;
			}
		}
		lcm=a*b/hcf;
    System.out.println(hcf);
    System.out.println(lcm);
	}

}

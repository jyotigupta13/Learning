import java.util.Scanner;
public class HcfRec {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number : ");
		int n1=sc.nextInt();
		System.out.println("Enter second number : ");
		int n2=sc.nextInt();
		int hcf=hcf(n1,n2);
		System.out.println("hcf : " + hcf);
		//int Lcm=(n1*n2)/hcf;
		int Lcm=lcm(n1,n2,hcf);
		System.out.println("Lcm : " + Lcm);

	}
	static int hcf(int n1,int n2) {
		if(n2!=0) {
			return hcf(n2,n1%n2);
		}
		else {
			return n1;
		}
	}
	static int lcm(int n1,int n2,int hcf) {
		return (n1*n2)/hcf;
	}

}

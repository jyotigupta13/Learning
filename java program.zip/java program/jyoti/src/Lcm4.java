import java.util.Scanner;
public class Lcm4 {

	public static void main(String[] args) {
		int hcf=1,i=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first no : ");
		int n1=sc.nextInt();
		System.out.println("Enter second no : ");
		int n2=sc.nextInt();
		for(i=2;i<=n1 && i<=n2;++i) {
			if(n1%i==0 && n2%i==0) {
				hcf=i;
				break;
			}
		}
		System.out.println("hcf= " + hcf);
		int lcm=(n1*n2)/hcf;
		System.out.println("lcm = " + lcm);
		/*
		 * gcd=(n1<n2) ? n1:n2; while(true) {
		 * 
		 * if(n1%gcd==0 && n2%gcd==0) { System.out.println("gcd " + gcd); break; }
		 * gcd++; }
		 */

	}

}

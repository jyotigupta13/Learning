
public class PiramidFloyd {

	public static void main(String[] args) {
		int i,j,num=0;
		for(i=1;i<=4;++i) {
			for(j=1;j<=i;++j) {
				System.out.print(++num + " ");
			}
			System.out.println();
		}
		
	}

}

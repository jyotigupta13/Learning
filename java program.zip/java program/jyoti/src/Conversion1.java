import java.util.Scanner;
public class Conversion1 {
	
	public static void main(String[] args) {
		Conversion1 c=new Conversion1();
		int binaryNo;
		int p=0;
		double decimal=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter binary no");
		int s=sc.nextInt();
		while(true) {
		if(s==0) {
			break;
		}
		else {
		binaryNo=s%10;
		decimal=decimal+binaryNo*Math.pow(2, p);
		s=s/10;
		++p;
		}
		}
		System.out.println("decimal conversion of binary no is : " + decimal);
		
	}

}

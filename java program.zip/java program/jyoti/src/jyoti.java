
public class jyoti {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("hi");
		int a=2,b=3,temp;
		//System.out.println("enter a and b");
		System.out.println("Before swap");
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		temp=b;
		b=a;
		a=temp;
		System.out.println("After swap\n a = " + a + "\n b = " + b);
		
		
	}

} 

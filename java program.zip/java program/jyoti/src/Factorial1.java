import java.util.Scanner;
public class Factorial1 {

	public static void main(String[] args) {
		int fact=1,i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		for(i=2;i<=n;i++) {
			fact=fact*i;
		}
		System.out.println("Factorial is : " + fact);
		
	}

}


	class A{  
			public static void main(String args[]){  
			 System.out.println("hello"); 
			for(int i=0;i<args.length;i++)  
			System.out.println(args[i]);  
			  
			}  
			}  

	
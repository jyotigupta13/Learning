import java.util.Scanner;

public class UpperString {

	public static void main(String[] args) {
		int i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string : ");
		String s=sc.nextLine();
		for(i=0;i<s.length();i++) {
			char temp=s.charAt(i);
			if(temp>=97 && temp<=122) {
				temp=(char)(temp-32);
			}
			System.out.print(temp);
		}

	}

}

import java.util.Scanner;
public class Swap2 {

	public static void main(String[] args) {
		int c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first no : ");
		int a=sc.nextInt();
		System.out.println("Enter second no : ");
		int b=sc.nextInt();
		System.out.println("before swap :\na=" + a + "\nb=" + b );
		c=b;
		b=a;
		a=c;
		System.out.println("After swap :\na=" + a +"\nb=" + b);
		

	}

}

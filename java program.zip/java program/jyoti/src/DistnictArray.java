
public class DistnictArray {

	
	public static void main(String[] args) {
		int i,j;
		int a[]={2,3,7,5,4,3,2};
		int n=a.length;
		System.out.print("Array is: ");
		for(i=0;i<n;i++){
			System.out.print(a[i] + " ");
		}
		System.out.println();
		System.out.println("the distinct element of an array are:");
		for(i=0;i<n;i++){
			for(j=0;j<i;j++)
				if(a[i]==a[j])
					break;
			
				if(i==j)
					System.out.print(a[i] + " ");
			
		}

	}

}

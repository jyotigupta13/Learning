import java.util.Scanner;
public class SumOfNaturalNo {

	public static void main(String[] args) {
		int i,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter range upto : ");
        int n=sc.nextInt();
        for(i=1;i<=n;i++) {
        	sum=sum+i;
        }
        System.out.println("sum is : " + sum);
	}

}

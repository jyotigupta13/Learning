import java.util.Scanner;
public class FrquencyOfDigit {

	public static void main(String[] args) {
		int i,count=0;
		Scanner sc=new Scanner(System.in);
		int a[]=new int[10];
	    System.out.println("Enter element of array : ");
		for(i=0;i<10;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("enter no for counting the frequency of occurance : ");
          int n=sc.nextInt();
	   for(i=0;i<10;i++) {
          if(a[i]==n) {
        	  count++;
          }
        	  
	   }
	   System.out.println("number occur in array " + count + " time");
	   
	}

}

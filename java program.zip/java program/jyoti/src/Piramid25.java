
public class Piramid25 {

	public static void main(String[] args) {
		int i,j,num=0;
		for(i=0;i<=6;i++) {
			for(j=1;j<=i;j++) {
				System.out.print(0);
				
			}
		
			
			for(j=0;j<=i;j++) {
				if(i==j)
				System.out.print(num++);
			}
			for(j=6;j>i;j--) {
				System.out.print(0);
			}
			
			System.out.println();
	}

	}

}

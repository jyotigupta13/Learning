import java.util.Scanner;
public class GcdRec {
	static int i=1,n1,n2,Gcd;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first no : ");
		GcdRec s1=new GcdRec();
	     n1=sc.nextInt();
		System.out.println("Enter second no : ");
		 n2=sc.nextInt();
		GcdRec s=new GcdRec();
		s1.Gcd();
		

	}
	void Gcd(){
	System.out.println("Gcd is : ");
	for(i=1;i<=n1 && i<=n2;++i) {
		if(n1%i==0 && n2%i==0) {
			 Gcd=i;
			
		}
		
		/*else {
			Gcd();
		}*/
	}
	System.out.print(Gcd);
	}

}

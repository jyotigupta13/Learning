import java.util.*;
public class J1 {

	public static void main(String[] args) {
		String rev="";
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string : ");
		String s=sc.nextLine();
		int length=s.length();
		for(int i=length-1;i>=0;i--){
			 rev= rev+s.charAt(i);
		}
		if(s.equals(rev)){
		  System.out.println("palindrom");
		}
		else{
			System.out.println("Not palindrom");
		}
	}

}

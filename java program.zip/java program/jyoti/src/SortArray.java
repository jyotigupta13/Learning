import java.util.Scanner;
public class SortArray {

	public static void main(String[] args) {
		int temp;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length of string:");
		int length=sc.nextInt();
		int a[]=new int[length];
		//String a[]=new String[length];
		
		System.out.println("Enter your array value of length");
		for(int i=0;i<length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.print("unsorted list are : " + "{");
		for(int i=0;i<length;i++) {
			System.out.print(a[i] +",");
		}
		System.out.println("}");
		
		for(int i=1;i<a.length;i++) {
			for(int j=i;j>0;j--) {
				if(a[j]<a[j-1]) {
					temp=a[j];
					a[j]=a[j-1];
					a[j-1]=temp;
				}
			}
		}
		System.out.print("sorted list are : {");
		for(int i=0;i<a.length;i++) {
			System.out.print(a[i] + ",");
		}
		System.out.println("}");
		System.out.println("output of half in adssending and half in decending order are : ");
		for(int i=0;i<a.length/2;i++) {
			System.out.print(a[i] + ",");
		}
		for(int i=length-1;i>=a.length/2;i--) {
			System.out.print(a[i] + ",");
		}
	}

}

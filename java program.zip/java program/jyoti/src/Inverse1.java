import java.util.Scanner;
public class Inverse1 {

	public static void main(String[] args) {
		int i,j,x,y,z,det;
		System.out.println("Enter element in matrix in row wise : ");
		Scanner sc=new Scanner(System.in);
		int a[][]=new int[3][3];
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("matrix is : ");
		for(i=0;i<3;i++){
			for(j=0;j<3;j++){
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		x=(a[0][0] * (a[1][1]*a[2][2] - a[1][2]*a[2][1]));
		y=(a[0][1] * (a[1][0]*a[2][2] - a[1][2]*a[2][0]));
	    z=(a[0][2] * (a[1][0]*a[2][1] - a[1][1]*a[2][0]));
	    det=x-y+z;
	    
	    System.out.println("transpose of matrix : ");
	    for(i=0;i<3;i++) {
	    	for(j=0;j<3;j++) {
	    		System.out.print(a[j][i] + " ");
	    	}
	    	System.out.println();
	    }
	    
	   
	}

}

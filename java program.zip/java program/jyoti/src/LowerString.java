import java.util.Scanner;
public class LowerString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string : ");
		String s=sc.nextLine();
		System.out.println(s.toLowerCase());
		System.out.println(s.toUpperCase());
	}

}

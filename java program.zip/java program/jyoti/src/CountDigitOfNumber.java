import java.util.Scanner;
public class CountDigitOfNumber {

	public static void main(String[] args) {
		int a,count=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		int temp=n;
		while(n>0) {
			n=n/10;
			count=count+1;
		}
		System.out.println("no of digit in " +  temp + " is : " + count);

	}

}

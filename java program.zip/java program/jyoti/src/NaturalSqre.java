import java.util.Scanner;
public class NaturalSqre {

	public static void main(String[] args) {
		int i;
		double sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter range upto : ");
		int n=sc.nextInt();
		for(i=1;i<=n;i++) {
			sum=sum+Math.pow(i,2);
			
		}
		System.out.println("sqre sum : " + sum);
		double secondSum=(n * (n+1) * (2*n+1))/6;
		System.out.println(secondSum);

	}

}

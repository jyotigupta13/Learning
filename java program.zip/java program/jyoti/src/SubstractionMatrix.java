import java.util.Scanner;
public class SubstractionMatrix {

	public static void main(String[] args) {
        int i,j;
       // int a[][]=new int[2][2];
        //int b[][]=new int[2][2];
         int a[][]= {{1,2},{2,3}};
         int b[][]= {{1,3},{4,2}};
         int sub[][]=new int[2][2];
         
         for(i=0;i<2;i++) {
        	 for(j=0;j<2;j++) {
         sub[i][j]=a[i][j]-b[i][j];
        	 }
         }
         System.out.println("substraction : ");
         for(i=0;i<2;i++) {
        	 for(j=0;j<2;j++) {
         
         System.out.print(sub[i][j] + "\t");
        	 }
        	 System.out.println();
         }


	}

}

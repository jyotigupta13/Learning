import java.util.Scanner;
public class AreaOfCircle {

	public static void main(String[] args) {
		double area;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter radius : ");
		double r=sc.nextInt();
		area=3.14*r*r;
		System.out.println("area of circle of radius " + r + " is " + area);
		System.out.printf("area of %.02f", area);

	}

}

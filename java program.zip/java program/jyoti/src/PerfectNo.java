import java.util.Scanner;
public class PerfectNo {

	public static void main(String[] args) {
		int i,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no : ");
		int n=sc.nextInt();
		for(i=1;i<n;i++) {
			if(n%i==0) {
				sum=sum+i;
			}
			
		}
		if(n==sum) {
		System.out.println("perfect");
		}
		else {
			System.out.println("not perfect");
		}

	}
	
}

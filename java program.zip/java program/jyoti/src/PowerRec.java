import java.util.Scanner;
public class PowerRec {
 static int temp,base,exp;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter base : ");
		int base=sc.nextInt();
		System.out.println("Enter exp : ");
		int exp=sc.nextInt();
		System.out.println("power of number is : ");
		 temp=Power(base,exp);
		System.out.println(temp);
		//System.out.println(temp);
	}
	 static int Power(int base,int exp) {
		 if(exp!=0) {
			 return (base*Power(base,exp-1));
		 }
		 else {
			 return 1;
		 }
		  
		 	 }

}

import java.util.Scanner;
public class Big {

	public static void main(String[] args) {
		int a,b;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter no");
	    a=sc.nextInt();
	    b=sc.nextInt();
	//	int x=Integer.parseInt(a);
	//	int y=Integer.parseInt(b);
		if(a>b)
			System.out.println(a + " is largest");
		else
			System.out.println(b + " is largest");

	}

}

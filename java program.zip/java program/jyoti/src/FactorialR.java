import java.util.Scanner;
public class FactorialR {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		FactorialR s=new FactorialR();
		int factorial=s.fact(n);
      System.out.println("Factorial is : " + factorial);
	}
	int fact(int n) {
		int output;
		if(n==0) {
			return 1;
		}
		else {
			output=n*fact(n-1);
			return output;
		}
	}

}

import java.util.Scanner;
public class Stringrever {

	
	public static void main(String[] args) {
		char a[]={'j','y','o','t','i'};
		System.out.println("reverse of jyoti");
		for(int i=a.length-1;i>=0;i--){
			System.out.print(a[i]);
		}

	}

}

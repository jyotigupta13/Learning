import java.util.Scanner;
public class Conversion {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter binary number");
        String a=sc.nextLine();
        int decimal=Integer.parseInt(a,2);
        System.out.println("decimal conversion is : " + decimal);
	}

}

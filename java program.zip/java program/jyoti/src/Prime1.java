import java.util.Scanner;
public class Prime1 {

	public static void main(String[] args) {
		int i,c=0;
		Scanner sc=new Scanner(System.in);
	    System.out.println("enter number to check no is prime or not");
		int n=sc.nextInt();
		for(i=1;i<=n;i++) {
			if(n%i==0) {
				c=c+1;
			}
		}
			if(c==2) {
				System.out.println(n +" is prime number");
			}
			else {
				System.out.println(n + " number is not prime");
				
			}
		
	}

}

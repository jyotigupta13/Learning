import java.util.Scanner;
public class DecimalToBinary {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter decimal No. : ");
		int n=sc.nextInt();
		int binary[]=new int[100];
		int i=0,j;
		while(n>0) {
			binary[i]=n%2;
			n=n/2;
			i++;
		}
		System.out.println("Conversion in Binary no are : ");
		for(j=i-1;j>=0;j--) {
			System.out.print(binary[j]);
		}
		
	}

}

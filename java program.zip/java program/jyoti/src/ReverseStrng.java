import java.util.Scanner;
public class ReverseStrng {

	public static void main(String[] args) {
		String reverse="";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string : ");
		String s=sc.nextLine();
		int length=s.length();
		for(int i=length-1;i>=0;i--) {
		  reverse=reverse+s.charAt(i);
		}
		System.out.println("reverse : " + reverse);
	}

}

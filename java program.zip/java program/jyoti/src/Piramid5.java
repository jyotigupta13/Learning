
public class Piramid5 {

	public static void main(String[] args) {
		int i,j, row=5;
		for(i=row;i>=1;--i) {
			for(j=1;j<=i;++j) {
				System.out.print("*" + " ");
			}
			System.out.println();
		}

	}

}

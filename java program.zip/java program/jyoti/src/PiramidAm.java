
public class PiramidAm {

	public static void main(String[] args) {
		int i,j,num=1;
		for(i=1;i<=5;i++) {
			num=1;
			
			for(j=1;j<=2*i-1;j++) {
				System.out.print(num++ + " ");
				
			}
			System.out.println();
			
		}
		for(i=4;i>=1;i--) {
			num=1;
			for(j=1;j<=2*i-1;j++) {
				System.out.print(num++ + " ");
			}
			System.out.println();
		}

	}

}

import java.util.*;
public class J {

	
	public static void main(String[] args) {
		char temp='0';
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String s=sc.nextLine();
		for(int i=0;i<s.length();i++){
			temp=s.charAt(i);
			if(temp>=65 && temp<=90){
				temp=(char)(temp+32);
			}
			System.out.print(temp);
		}
		
		
	}

}

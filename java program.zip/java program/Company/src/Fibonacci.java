import java.util.*;
public class Fibonacci {

	
	public static void main(String[] args) {
		int a1=0,a2=1,sum;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter range : ");
		int range = sc.nextInt();
		System.out.println("fibonacci series = " );
		for(int i=1; i<=range; i++){
		System.out.print(a1 + " ");
		sum=a1+a2;
		a1=a2;	
		a2=sum;
		
		}
		

	}

}

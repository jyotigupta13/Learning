
public class SwapNo {
static int a=3,b=5,c;
	public static void main(String[] args) {
		System.out.println("Before swap : " + "a = " + a + ", b = " + b);
		c=a;
		a=b;
		b=c;
		System.out.println("After swap : " + "a = " + a + ", b = " + b);

	}

}

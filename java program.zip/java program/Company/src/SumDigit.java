//	Program to find out sum of digits of given number.

import java.util.*;
public class SumDigit {

	
	public static void main(String[] args) {
		int sum=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number : ");
		int num = sc.nextInt();
		int number=num;
		while(num>0){
		int a = num % 10;
		sum = sum+a;
		num=num/10;
		}
		System.out.println("sum of digits of given number : " + sum);
		
	}

}

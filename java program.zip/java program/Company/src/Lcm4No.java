
public class Lcm4No {
static int a=2,b=3,c=4,d=6;

	public static void main(String[] args) {
		int x=(a>b)?a:b;
		int y=(x>c)?x:c;
		int large=(y>d)?y:d;
		
		int Lcm=large;
		while(true){
		  if(Lcm%a==0 && Lcm%b==0 && Lcm%c==0 && Lcm%d==0){
			  System.out.println("Lcm is : " + Lcm);
			  break;
		  }
		  Lcm++;
		}
	}

}

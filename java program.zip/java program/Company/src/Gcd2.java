
public class Gcd2 {

	public static void main(String[] args) {
		int a=2;
		int b=4;
		int Gcd = Gcd(a,b);
		System.out.println("Gcd is : " + Gcd);
		int Lcm = (a*b)/Gcd;
		System.out.println( "Lcm is : " + Lcm);
	}
	
	static int Gcd(int a,int b){
		int Gcd=1;
		
		if(b!=0){
			return Gcd(b,a%b);
		 }
		else{
			return a;
		}
		
	}
		
}



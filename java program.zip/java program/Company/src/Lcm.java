
public class Lcm {
static int a=2;
static int b=4;
	
	public static void main(String[] args) {
		int Lcm;
		Lcm = a>b ? a : b;
		while(true){
		if(Lcm%a==0 && Lcm%b==0){
			System.out.printf("Lcm of %d and %d is %d",a,b,Lcm);
			break;
		 }
		Lcm++;
		}

	}

}

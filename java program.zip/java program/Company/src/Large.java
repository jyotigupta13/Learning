import java.util.*;
public class Large {
static int a=3,b=4,c=5,d=6;

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a[]=new int[4];
	System.out.println("Enter four integer value : ");
	   for(int i=0;i<a.length;i++){
	    a[i]=sc.nextInt();
	   }
	   int max=a[0];
	   for(int i=0;i<a.length;i++){
	    if(max < a[i]){
		max=a[i];
		}
	   
	   }
	   System.out.println("max is : " + max);
	 
	   
	}
}

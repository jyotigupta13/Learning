import java.util.*;
public class Gcd {
static int a;
static int b;
int i;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Gcd s1 = new Gcd();
		
		System.out.println("Enter first number : ");
		 s1.a = sc.nextInt();
		System.out.println("Enter second number : ");
		 s1.b = sc.nextInt();
		int Gcd = Gcd(a,b);
		System.out.println("Gcd is : " + Gcd);
		

	}
	static int Gcd(int a, int b){
		int Gcd = 1;
		for(int i=1;i<=a & i<=b; i++){
			if(a%i == 0 && b%i==0){
				 Gcd = i;
			}
		}
		return Gcd;
	}

}

/*
 *  Print pattern
    Input:3
    Output:
      3 3 3
      3 1 3
      3 2 3
      3 3 3

 */
import java.util.*;
public class Pattern3 {

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 3");
		for(int i=1;i<=4;i++){
			for(int j=1;j<=3;j++){
				System.out.print("3");
			}
			System.out.println();
		}
	}

}

class Mythread extends Thread
{
  public void run()
  {
  System.out.println("mythread");
  }

  }
  class Gkp 
  {
     public static void main(String[] ar)
     {
     Mythread t= new Mythread();
     t.start();
     System.out.println("main");
     }
     }
class Student
{
}
class Emp
{
}
class Bit
{
}
class Ltbp
{ 
	void m1(student s,Emp
}
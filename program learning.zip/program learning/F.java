class F 
{   
	void m1(){
		System.out.println("hiii");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello Jyoti");
		F aaa=new F();
		aaa.m1();

	}
}

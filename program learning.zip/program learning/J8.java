class J8{
	int k;
	int l=100;
	static int m;
	static final int n=100;
    int a=100;
    static int b=20;
    static void m1(int a,int b)
   {
		final int c=0;
		//c=10;
		//static int d=100;  not allowed
		//public int e=100;  not allowed
		//int f;  not allowed
System.out.println("Hellloooooo");
J8 t=new J8();
System.out.println(t.a);
System.out.println(J8.b);
System.out.println(c);
t.m2(10);

}
void m2(int a)
{
System.out.println("Haaaaa");
System.out.println(a);
System.out.println(J8.b);
System.out.println(this.a);

}
public static void main(String[] ar){
J8 t=new J8();
System.out.println(t.a);
System.out.println(J8.b);
t.m1(10,20);
t.m2(10);
}
}
class  Ltbp
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("Initial");
		Thread.sleep(1000);
		//System.out.println(10/0);
			System.out.println("this");
		
		
		System.out.println("rest");

	}
}

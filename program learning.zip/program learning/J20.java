class J20 
{

	J20(){
	System.out.println("hello");
    }
	void m1(){
	System.out.println("hii");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		J20 t=new J20();
		t.m1();
	}
}

class  Ltbp
{
	public static void main(String[] args) 
	{
		System.out.println("Initial");
		try{
			System.out.println("hii");
		Thread.sleep(1000);
		System.out.println(10/0);
		System.out.println("hello");
		}
		catch(Exception e)
		{
			System.out.println("this");
		}
		
		/*catch(ClassNotFoundException a)
		{
			System.out.println("haaaaa");
		}
		*/
		System.out.println("rest");

	}
}

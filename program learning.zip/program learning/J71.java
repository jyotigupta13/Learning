interface  Ltbp
{
	interface It
	{
		void m1();
		void m2();
	
	}
}  
class Gkp implements Ltbp.It
{
	public void m1(){
		System.out.println("this is m1");
}
public void m2(){
	  System.out.println("m2");
}

	public static void main(String[] args) 
	{
		Ltbp.It t=new Gkp();
		t.m1();
		t.m2();
	}
}

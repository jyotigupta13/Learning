class Lt 
{
	int eid;
	double esal;
	String ename;
	Lt(int eid,double esal,String ename)
	{
		this.eid=eid;
		this.esal=esal;
		this.ename=ename;


	}
	void show(){
		System.out.println(eid);
		System.out.println(esal);
		System.out.println(ename);
	}
	public static void main(String[] args) 
	{
		Lt t=new Lt(10,2000.20,"Jyoti");
		t.show();
		Lt t1=new Lt(20,10000.20,"vandu");
	    t1.show();
	}
}

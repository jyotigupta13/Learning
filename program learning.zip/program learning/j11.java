class J11 
{
	int a=10;
	static int b=20;
	int d=500;
	int e=012;
	//int f=018;
	int f=0x12A;
	//int g=0X12r;
	int g=2147483647;
	int g1=-2147483648;
	//float f=10.2f;
	//float k=10.2 F;
	int m=1_2_4;
	//int m5=_123_4;
	//int m6=123_;
	//int m7=0b1212;
	int m8=0B1111111;



	void m1(int a,int b)
	{
		char c=65535;
		System.out.println(a);
		System.out.println(b);
		System.out.println(this.a);
		System.out.println(J11.b);
		System.out.println(c);

		System.out.println(d);
		System.out.println(f);
		System.out.println(g);
		System.out.println(g1);
		System.out.println(m);
		System.out.println(m8);
		
	}
	static void m2(int a)
	{
		J11 t=new J11();
		System.out.println(a);
		System.out.println(t.a);
		System.out.println(J11.b);
	}
	public static void main(String[] args) 
	{  
	  J11 t=new J11();
	  t.m1(40,20);
	  J11.m2(30);
		System.out.println("Hello World!");
	}
}

class H4 
{
	H4()
	{ 
		System.out.println("hey");
	}
	void marrage(){
		System.out.println("ha");
	}
}
class Gkp extends H4
{
	Gkp()
	{
		super();
		System.out.println("hii");
	}
    void marrage(){
		System.out.println("na");
		super.marrage();
	}

	public static void main(String[] args) 
	{
        H4 t=new H4();
		t.marrage();
		Gkp g=new Gkp();
		g.marrage();
		//System.out.println("Hello World!");
	}
}

class Ltbp
{
	public static void main(String[] args) 
	{
		int []a=new int[3];
		a[0]=1;
		a[1]=2;
		a[2]=3;
 System.out.println(a[1]);
 System.out.println(a[2]);
 //System.out.println(a[3]);
 System.out.println(a);
 System.out.println(a.toString());
 String s="sumi";
 System.out.println(s);
 System.out.println(s.toString());
 Ltbp t=new Ltbp();
 System.out.println(t);
 System.out.println(t.toString());
	}
}

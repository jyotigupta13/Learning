class J7{
    int a;
    static int b;
    static void m1(int a,int b)
   {
System.out.println("Hellloooooo");
J7 t=new J7();
System.out.println(t.a);
System.out.println(J6.b);
t.m2(10);
}
void m2(int a)
{
System.out.println("Haaaaa");
System.out.println(a);
System.out.println(J7.b);
}
public static void main(String[] ar){
J7 t=new J7();
System.out.println(t.a);
System.out.println(J7.b);
t.m1(10,20);
t.m2(10);
}
}
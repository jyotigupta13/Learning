import java.util.*;
class Gkp
{
      public static void main(String[] ar)
      {
      Scanner s=new Scanner(System.in);
      System.out.println("enter your age");

      int age=s.nextInt();
      if(age>18)
      {
      System.out.println("eligible for voting");
      }
      else
		  {
      System.out.println("not eligible for votaing");
		  }
      }
}
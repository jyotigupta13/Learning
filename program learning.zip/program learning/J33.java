class Lt
{
 void m1()
 {
 System.out.println("ma");
 }
 {
 m1();
 System.out.println("instance block");
 }
 public static void main(String[] ar)
 {
 Lt t=new Lt();
 t.m1();
 }
 }
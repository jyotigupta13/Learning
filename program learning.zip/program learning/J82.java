class Ltbp 
{
	public static void main(String[] args) 
	{
		//System.out.println(10/0);
		System.out.println("initial code");
		try{
			System.exit(0);
		System.out.println(10/2);
		}
		catch(ArithmeticException aa)
		{
			System.out.println(10/5);
		}
			finally
			{
				System.out.println("fanally");
		}
		System.out.println("rest code");
	}
}

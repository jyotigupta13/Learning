class Mythread extends Thread
{
  public void run()
  {
	  for (int i=0;i<5;i++)
	  { 
		System.out.println("my thread");  
	  }
  }
}
 
//three thread that is main,start 2;
  
  class Gkp 
  {
     public static void main(String[] ar) //main thread
     {
     Mythread t= new Mythread();
     t.start();  //thread 0
	 Mythread t1=new Mythread();
	 t1.start(); //thread 1
	 for(int i=0;i<5;i++)
		 {
     System.out.println("main");
     }
	 }
	 }
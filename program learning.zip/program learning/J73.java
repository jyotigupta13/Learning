interface It
{
    void m1();
    void m2();
    void m3();
    void m4();
}

class X implements It
{
  public void m1()
  {
  }
  public void m2()
  {
  }
  public void m3()
  {
  }
  public void m4()
  {
  }
}

class Gkp extends X
{
  public void m1()
  {
     System.out.println("m1");
   }
public static void main(String[] ar)
{
   Gkp g=new Gkp();
   g.m1();
   }
   }
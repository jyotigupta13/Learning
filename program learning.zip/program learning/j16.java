class J16
{
  public static void main(String[] ar)
  {
    System.out.println("\'\";\\\\n/m\\n/u");
	char c1=\';
	System.out.println("c1");
    }
    }
class Jy 
{
	int a;
	int b;
	{
		int a=100; //local variable
		int b=200;  //local variable
		this.a=a;
		this.b=b;
	}
	public static void main(String[] args) 
	{
		Jy t=new Jy();
		System.out.println(t.a);
		System.out.println(t.b);

	}
}

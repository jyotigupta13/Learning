class Ltbp
{
    int a=1;
    int b=2;
    static int c=3;
}
class Gkp extends Ltbp
{
    int a=4;
    int b=5;
    static int c=6;
    void m1()
 {
    int a=10;
    int b=20;
    int c=40;
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
    System.out.println(this.a);
    System.out.println(this.b);
    System.out.println(Gkp.c);
    System.out.println(super.a);
    System.out.println(super.b);
    System.out.println(Ltbp.c);
    }
    public static void main(String[] ar){
    Gkp g=new Gkp();
    g.m1();
    }
    }
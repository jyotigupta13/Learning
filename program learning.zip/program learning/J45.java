class Ltbp 
{  
	Ltbp(int a,char c)
	{
		System.out.println("parent  1 constructor");
        }
    Ltbp()
	{
		System.out.println("Parent o constructr");
	}



	void m1(){
	System.out.println("this is m1");
       }
}
	class Gkp extends Ltbp
	{ 

        Gkp(int a){
			this(); 
			System.out.println("child constructor");
     	}
       Gkp()
		{
		   //super();
		   System.out.println("ha");
		}
		void m1()
		{
        System.out.println("this is m1 of gkp");
		super.m1();
		}
	
	public static void main(String[] args) 
	{
		Ltbp t=new Ltbp();
		t.m1();
		Gkp g=new Gkp(10);
        g.m1();
		
	}
}

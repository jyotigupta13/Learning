class J13 
{
	public static void main(String[] args) 
	{ // int a=10l;
	   //float f=a;
	byte b=10;
	//byte b=10.4;
    //byte b2=65535;
	//byte b3=128;
	byte b4='c';
	//byte b5="s";
	//byteb7='10.4'; 
	//byte c=128;

	int a1=10;
	//int a2=10.2;
	int a3='c';
	//int a4="c";
	//int a5=10.2f;
	//int a6=10l;
	//int a7=10f;
	
	long l1=2147483647;
	//long l2=2147483648;
	long l3=2147483648l;
	long l4='c';
	//long l5="s";
	//long l6='10.2';
	
	char c1=10;
	char c2='c';
	//char c3="c";
	char c4='1';
	char c5=65535;
	char c6='\u124A';
	char c7='\n';
	//char c8='\";
	//char c8='\';
	//char c11=\\";
	char c10='\\';
	String s1="s";
	//String s2='s';
	
	//int a8=0x124A;
	//int a9=012;
	//int a10=012.12F;
	//int a12=012.12;
	//float f1=12.1;
	float f2=12.1f;
	//float f3=0x12.0f;
	float f4=012.12f;
	//float f5=012.12;
	float f6='c';
	//float f7="c";
	float f8=10;
	System.out.println(b);
	//System.out.println(c);
		System.out.println("Hello World!");
		
	}
}

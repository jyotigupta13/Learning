class Ltbp implements Cloneable
{
    int a=10;
    public static void main(String... ar) throws CloneNotSupportedException
    {
    Ltbp t=new Ltbp();
    t.a=20;
    System.out.println(t.a);
    Ltbp t1=(Ltbp)t.clone();
    t.a=40;
    System.out.println(t.a);
    System.out.println(t1.a);


    }
}
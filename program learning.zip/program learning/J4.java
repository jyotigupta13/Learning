class J6{
int a=10;
static int b=20;
static void m1()
{
System.out.println("Hellloooooo");
J6 t=new J6();
System.out.println(t.a);
Syatem.out.println(J6.b);
}
void m2()
{
System.out.println("Haaaaa");
System.out.println(a);
System.out.println(J6.b);
}
public static void main(String[] ar){
J6 t=new J6();
System.out.println(t.a);
System.out.println(J6.b);
t.m1();
t.m2();
}
}
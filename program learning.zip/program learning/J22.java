class Abc
{

	Abc(){
	System.out.println("hello");
    }
	Abc(int a){
		System.out.println("bandar");
	}
	void m1(){
	System.out.println("hii");
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Abc t=new Abc();
		Abc t1=new Abc(10);
		t.m1();
		t1.m1();
	}
}

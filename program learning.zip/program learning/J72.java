class A extends B
class A extends A,B   ..not possible
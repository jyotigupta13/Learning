class J6{
    int a=100;
    static int b=20;
    static void m1(int a,int b)
   {
System.out.println("Hellloooooo");
J6 t=new J6();
System.out.println(t.a);
System.out.println(J6.b);
t.m2(10);

}
void m2(int a)
{
System.out.println("Haaaaa");
System.out.println(a);
System.out.println(J6.b);
System.out.println(this.a);

}
public static void main(String[] ar){
J6 t=new J6();
System.out.println(t.a);
System.out.println(J6.b);
t.m1(10,20);
t.m2(10);
}
}
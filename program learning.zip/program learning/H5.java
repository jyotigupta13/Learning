class H5 
{
	void m1(){
		System.out.println("hello");
	}
	void m2(){
		System.out.println("haa");
	}
}
class Gkp extends H5
{
	void m1(){
		System.out.println("hii");
	}

	public static void main(String[] args) 
	{
		H5 t=new H5();
		t.m1();
		Gkp g=new Gkp();
		g.m1();
		H5 t1=new Gkp();
		t1.m1();
		t1.m2();
		//System.out.println("Hello World!");
	}
}

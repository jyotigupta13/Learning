class Lt 
{
	static
	{
		System.out.println("first");
	}
	static
	{
		System.out.println("second");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

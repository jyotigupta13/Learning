class userthread extends Thread 
{
	public void run()
	{
		for(int i=0;i<20;i++)
		{
			System.out.println("user thread");
		}
		try
		{
			Thread.sleep(3000);
		}
		catch ()
		{
		}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

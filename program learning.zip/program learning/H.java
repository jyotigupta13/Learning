class H 
{
	static int a;
	int b;
	static int c;
	static
	{
	 int a=100;
	 int b=200;
	 H.a=a;
	 H.c=b;
	 System.out.println("Hello");
	}
	{
	  System.out.println("hi");
      int c=300;
	  b=c;
	}
	public static void main(String[] args) 
	{
		H tt=new H();
		System.out.println(H.a);
		System.out.println(tt.b);
		System.out.println(H.c);
	}
}

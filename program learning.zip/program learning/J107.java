class Mythread extends Thread
{
    public void run()
    {
      System.out.println("user thread");
      }
      }
      class Ltbp
      {
      public static void main(String[] ar) 
		  {
		  System.out.println(Thread.currentThread().getName());
		  System.out.println(Thread.currentThread().getPriority());

		  Mythread t=new Mythread();
		  t.start();
		  System.out.println(t.getName());
		  System.out.println(t.getPriority());
		  t.setName("jyoti");
		  System.out.println(t.getName());
		  t.setPriority(10);
		  System.out.println(t.getPriority());
		  }
	  }
	  
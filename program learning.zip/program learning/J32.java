class Lt 
{
	static int a;
	int b;
	static int c;
	static{
		int a=100;
		int b=200;
		Lt.a=a;
		Lt.c=b;
	}
	{
		int c=300;
		b=c;
	}
	public static void main(String[] args) 
	{
		System.out.println(Lt.a);
		Lt t=new Lt();
		System.out.println(t.b);
		System.out.println(Lt.c);
	}
}

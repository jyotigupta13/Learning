class J1
{   
	static void m1(){
		System.out.println("hiii");
	}
	public static void main(String[] args) 
	{
		
		
		J1.m1();
		System.out.println("Hello Jyoti");

	}
}

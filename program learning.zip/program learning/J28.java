class Jy 
{
	Jy()
	{
		System.out.println("0 arg");
	}
	Jy(int a)
	{
		System.out.println("1 arg");
	}
	{
		System.out.println("this instance block");
	}
	{
		System.out.println("haaaa");
	}
	  void m1(){
		  System.out.println("this is m1");
	  }
		public static void main(String[] args) 
	{
		Jy t=new Jy();
		t.m1();
		Jy t1=new Jy();
		t1.m1();

	}
}

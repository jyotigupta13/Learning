abstract class Ltbp
{
	abstract void m1();
	abstract void m2();
	abstract void m3();
}
class Bit extends Ltbp
{
	void m1(){
		System.out.println("hello m1");
	}
    void m2(){
		System.out.println("m2");
	}
	void m3(){
		System.out.println("m3");
	}
		public static void main(String[] args) 
	{
	  Bit b=new Bit();
	  b.m1();
	  b.m2();
	  b.m3();
	}
}

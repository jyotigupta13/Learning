class Jyoti1{
public static void main(String[] ar)
{
System.out.println("\t\n\t Hello sir");
}
}
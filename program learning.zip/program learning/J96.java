import java.util.*;
class NotValid extends Exception
{
}
class Gkp
{

      public static void main(String[] ar) throws NotValid
      {
      Scanner s=new Scanner(System.in);
      System.out.println("enter your age");

      int age=s.nextInt();
      if(age>18)
      {
      System.out.println("eligible for voting");
      }
      else
		  {
               throw new NotValid();
		  }
      }
}
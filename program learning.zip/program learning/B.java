public class B 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello bandaro");
	}
	//file name must be the class name.java
}
public class C
{
	public static void main(String[] args)
	{
	System.out.println("hii");
	}
}
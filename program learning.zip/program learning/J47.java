class Lt 
{
	public static void main(String[] args) 
	{
		System.out.println(3+4);
		System.out.println("Jyoti"+ 4 + 5);
		System.out.println(4+3+"Jyoti");
		System.out.println(7+" "+8+" "+"_");
	}
}

class J17
{
 int m1()
 {
  System.out.println("hi");
  //return 10;
  System.out.println("hello");
  return 10;
  }
  public static void main(String[] ar)
  {
    J17 t=new J17();
    t.m1();
    }
    }
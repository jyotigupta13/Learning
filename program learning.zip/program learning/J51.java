class Btech
{
}
class Cs extends Btech
{
}
class Ltbp 
{
	Btech m1()
	{
		System.out.println("this is m1");
	Btech b=new Btech();
	return b;
	}

}
class Gkp extends Ltbp
{
	Btech m1()
	{
		System.out.println("this is child m1");
		Btech c=new Btech();
		return c;

}
	public static void main(String[] args) 
	{
		Ltbp t= new Gkp();
		t.m1();
	}
}

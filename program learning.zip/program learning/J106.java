class Userthread extends Thread
{
    public void run()
    {
      System.out.println("user thread");
      }
      }
      class Ltbp
      {
      public static void main(String[] ar) throws InterruptedException
      {
	    UserThread t=new UserThread();
		Runtime.getRuntime().addShutdownHook(t);
		for(int i=0;i<10;i++)
		  {
			System.out.println("main");
			Thread.sleep(1000);
		  }
	  }
	  }
class H1 
{
	void m1(){
		System.out.println("hi");
	}
	{
		m1();
		System.out.println("hello");
	}
	public static void main(String[] args) 
	{
		H1 aa=new H1();
		aa.m1();
		System.out.println("Hello World!");
	}
}

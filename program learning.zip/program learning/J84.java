class  Ltbp
{
	public static void main(String[] args) 
	{
		System.out.println("Initial");
		try{
		Thread.sleep(1000);
		System.out.println(10/0);
		}
		catch(InterruptedException | ArithmeticException e)
		{
			System.out.println("this");
		}
		
		/*catch(ClassNotFoundException a)
		{
			System.out.println("haaaaa");
		}
		*/
		System.out.println("rest");

	}
}

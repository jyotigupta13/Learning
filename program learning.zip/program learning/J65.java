class Ltbp 
{
	int a=10;
	void m1(){
		System.out.println("hello");
	}
}
	class Gkp extends Ltbp
	{
		int a=20;
		void m1(){
			System.out.println("hii");
		}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Ltbp t=new Gkp();
		System.out.println(t.a);
		t.m1();
	}
}

class  Ltbp
{
	public static void main(String[] args) 
	{
	  //String s1="ltbp";
	  //String s2="ltbp";
	  String s3= new String("sk");
	  String s4=new String("sk");
	  if(s3==s4)
		{
		  System.out.println("hii");
		}
		else
		{
			System.out.println("bye");
		}
	}
}

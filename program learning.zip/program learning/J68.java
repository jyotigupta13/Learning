interface It
{
	void m1();
	void m2();
	void m3();
} 
	class Ltbp implements It
	{
		public void m1(){
			System.out.println("m1");
	}
	    public void m2(){
			System.out.println("m2");
		}
		public void m3(){
			System.out.println("m3");
		}
	public static void main(String[] args) 
	{
		Ltbp t=new Ltbp();
		t.m1();
		t.m2();
		t.m3();
	}
}

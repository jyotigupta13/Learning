class Ltbp 
{
	void m1(){
	System.out.println("this is m1");
	}
	void m2(){
		System.out.println("this is m2");
	}
}	
	class Gkp extends Ltbp
	{
		void m1()
		{
        System.out.println("this is m1 of gkp");
		super.m1();
		}
		void m3()
		{
			System.out.println("m3 of gkp");
		}
	
	public static void main(String[] args) 
	{
		Ltbp t=new Ltbp();
		t.m1();
		Gkp g=new Gkp();
        g.m1();
		
	}
}

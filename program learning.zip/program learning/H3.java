class H3 
{
	void m1()
	{
		System.out.println("this is parent m1");
	}
}
class Gkp extends H3
{
	void m1()
	{
		System.out.println("this is child m1");
		super.m1();
    } 

	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
       H3 t=new H3();
	   t.m1();
	   Gkp g=new Gkp();
	   g.m1();
	}
}

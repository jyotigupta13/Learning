
class Ltbp 
{
	void m1() throws InterruptedException //Exception
	{
		Thread.sleep(1000);
	}
}
class Gkp extends Ltbp
{
	void m1() throws InterruptedException  //(sub class or no Exception)
	{
	  System.out.println("haaaa");
	}

	public static void main(String[] args) throws InterruptedException
	{
		Gkp g=new Gkp();
		g.m1();
	}
}

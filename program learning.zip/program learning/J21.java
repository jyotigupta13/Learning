class J21 
{

	J21(){
	System.out.println("hello");
    }
	J21(int a){
		System.out.println("bandar");
	}
	void m1(){
	System.out.println("hii");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		J21 t=new J21();
		t.m1();
	}
}

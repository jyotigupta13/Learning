class J2
{   
	 void m1(){
		System.out.println("hiii");
	
	}
	void m2(){
		System.out.println("hello");
		m1();

	}
	public static void main(String[] args) 
	{
		
		J2 aaa=new J2();
		aaa.m2();
		System.out.println("Hello Jyoti");
		aaa.m1();

	}
}

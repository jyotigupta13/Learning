class Ltbp 
{
	void m1()
	{
		System.out.println("this is parent m1");
	}
}
class Gkp extends Ltbp
{
	void m1() throws ArithmeticException
	{
	  System.out.println("haaaa");
	}

	public static void main(String[] args) 
	{
		Gkp g=new Gkp();
		g.m1();
	}
}

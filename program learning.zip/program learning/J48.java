class  Lt
{
	void m1()
		{
		System.out.println{"hello");
		}
		void m1(int a)
		{
			System.out.println("hi");
		}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
      Lt t=new Lt();
	  t.m1();
	  t.m1(10);
	}
}

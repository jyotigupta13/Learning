class G 
{   
	void m1(){
		System.out.println("hiii");
	}
	public static void main(String[] args) 
	{
		
		G aaa=new G();
		aaa.m1();
		System.out.println("Hello Jyoti");

	}
}

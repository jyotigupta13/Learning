class  Ltbp
{
	public static void main(String[] args) 
	{
	  String s1="ltbp";
	  String s2="ltbp";
	  //String S3= new String("sk");
	  //String s4=new String("sk");
	  if(s1==s2)
		{
		  System.out.println("hii");
		}
		else
			System.out.println("bye");
	}
}

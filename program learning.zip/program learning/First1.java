import java.awt.*;
class First1{
First1(){
Frame f1=new Frame();
Button b=new Button("click");
b.setBounds(60,150,50,30);
f1.add(b);
f1.setSize(300,300);
f1.setLayout(null);
f1.setVisible(true);
}
public static void main(String[] ar){
First1 f=new First1(); 
}
}
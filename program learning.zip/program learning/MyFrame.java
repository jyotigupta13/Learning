import java.awt.*;
class MyFrame{
Frame f;
TextField tf;
Button b1;
MyFrame()
{
f=new Frame();
tf=new TextField();
tf.setBounds(40,40,60,30);
f.add(tf);
b1=new Button("ok");
b1.setBounds(40,100,40,40);
f.add(b1);
f.setLayout(null);
f.setSize(400,400);
f.setVisible(true);
}
public static void main(String[] ar)
{
new MyFrame();
}
}
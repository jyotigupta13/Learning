class Ltbp
{
	public static void main(String[] args) 
	{
try{
		System.out.println(10/0);
}
catch(ArithmeticException a)
{
a.printStackTrace();
System.out.println(a.getMessage());


	}
}





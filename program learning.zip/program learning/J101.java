class Mythread extends Thread
{
  public void start()
  {
	  for (int i=0;i<5;i++)
	  { 
		System.out.println("my thread");  
	  }
  }
}
 
//only one thread that is main
  
  class Gkp 
  {
     public static void main(String[] ar)
     {
     Mythread t= new Mythread();
     t.start();
	 for(int i=0;i<5;i++)
		 {
     System.out.println("main");
     }
	 }
	 }
class  Ltbp
{
	void m3() throws /*Interrupted*/Exception{
		m2();

	}
	void m2() throws Exception{
		m1();
	}
	void m1() throws /*Interrupted*/Exception
		{
            Thread.sleep(1000);
		}
	public static void main(String[] args) throws Exception
	{
		System.out.println("Initial");
		Ltbp t=new Ltbp();
		t.m3();
		//System.out.println(10/0);
			System.out.println("this");
		
		
		System.out.println("rest");

	}
}

class J9 
{
	int a=10;
	static int b=20;
	void m1(int a,int b)
	{
		int c=50;
		System.out.println(a);
		System.out.println(b);
		System.out.println(this.a);
		System.out.println(J9.b);
	}
	static void m2(int a)
	{
		J9 t=new J9();
		System.out.println(a);
		System.out.println(t.a);
		System.out.println(J9.b);
	}
	public static void main(String[] args) 
	{  
	  J9 t=new J9();
	  t.m1(40,20);
	  J9.m2(30);
		System.out.println("Hello World!");
	}
}

class Ltbp 
{  
	Ltbp()
	{
        }
	void m1(){
	System.out.println("this is m1");
       }	
	class Gkp extends Ltbp
	{ 

        Gkp(){
		//	super();       //added by compiler
     	}

		void m1()
		{
        System.out.println("this is m1 of gkp");
		super.m1();
		}
	
	public static void main(String[] args) 
	{
		Ltbp t=new Ltbp();
		t.m1();
		Gkp g=new Gkp();
        g.m1();
		
	}
}

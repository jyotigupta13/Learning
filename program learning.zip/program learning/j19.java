class J17 
{
	//default constructor is added by compiler
	J17(){
    }
	void m1(){
	System.out.println("hii");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		J17 t=new J17();
		t.m1();
	}
}

class J14

{
	public static void main(String[] args) 
	{   char c1='\\';
	     
		System.out.println("Hello World!");
		System.out.println("\'\"\';\\\\n/m\\n/u\\ ");
		System.out.println(c1);
		System.out.println("/n");
	}
}

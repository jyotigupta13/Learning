class Ltbp 
{
	int eid;
	double esal;
	String ename;
	static String comp;
	int ensentive;
	  Ltbp(int eid,double esal,String ename)
	{
		  this.eid=eid;
		  this.esal=esal;
		  this.ename=ename;
	}
	{
		int ensentive=100;
		this.ensentive=ensentive;
	}
	static
    {
		Ltbp.comp="Ltbp";
	}
	void show()
	{
		System.out.println(eid);
		System.out.println(esal);
		System.out.println(ename);
		System.out.println(Ltbp.comp);
		System.out.println(ensentive);
	}
	public static void main(String[] args) 
	{
		Ltbp t1=new Ltbp(10,2000,"sx");
		t1.show();
		Ltbp t2=new Ltbp(20,3000,"jx");
		t2.show();
	}
}

class mythread implements Runnable
{
  public void run()
  {
  for(int i=0;i<10;i++)
  {
   System.out.println("usr thread");
   }
   }
   }
   class Lt
   {
   public static void main(String[] ar)
   {
   mythread m=new mythread();
   Thread m1=new Thread(m);
   m1.start();
   for(int i=0;i<10;i++)
   {
   System.out.println("main");
   }
   }
   }
class Hello 
{
 static	int a;
	int b;
	{
		int a=100;
		int b=200;
		Hello.a=a;
		this.b=b;
	}
	public static void main(String[] args) 
	{
		Hello t=new Hello();
		System.out.println(t.a);
		System.out.println(t.b);
	}
}

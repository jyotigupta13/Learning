class Ltbp 
{
	void m1()
	{
		System.out.println("this is m1");
	}
}
class Gkp extends Ltbp
{
	void m1()
	{
		System.out.println("this is child m1");

}
	public static void main(String[] args) 
	{
		Ltbp t= new Gkp();
		t.m1();
	}
}

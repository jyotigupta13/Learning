class J3
{   
	static  void m1(){
		System.out.println("hiii");
	 J3 t=new J3();
	 t.m2();
	}
	void m2(){
		System.out.println("hello");

	}
	public static void main(String[] args) 
	{
		
		J3 aaa=new J3();
		aaa.m2();
		J3.m1();
		System.out.println("Hello Jyoti");
	

	}
}

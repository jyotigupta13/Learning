class Ltbp
 {
    int a;
    int b;
{
   a=100;
   b=200;
}
public static void main(String args[])
{
  Ltbp t=new Ltbp();
  System.out.println(t.a);
  System.out.println(t.b);
}
 }
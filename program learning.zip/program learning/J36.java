class Ltbp 
{
	void m1(){
	System.out.println("this is m1");
	}
	void m2(){
		System.out.println("this is m2");
	}
}	
	class Gkp extends Ltbp
	{
		void m4()
		{
        System.out.println("this is m1 of gkp");
		}
		void m3()
		{
			System.out.println("m3 of gkp");
		}
	
	public static void main(String[] args) 
	{
		
		Gkp g=new Gkp();
        g.m1();
		g.m2();
		g.m3();
		g.m4();
	}
}

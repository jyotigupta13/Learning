class J15
{
   public static void main(String[] ar)
   {
     byte b1=10;

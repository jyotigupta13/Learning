class lt
{
	void m1()
	{
		System.out.println("0 argm1");
	}
	void m1(int a)
	{
		System.out.println("1 arg m1");	
	}
	public static void main(String[] args)
	{
		lt t=new lt();
		t.m1();
		t.m1(10);
	}
}
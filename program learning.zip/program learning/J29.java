class Jy 
{
	int a;
	int b;
	{
		a=100;
		b=200;
	}
	public static void main(String[] args) 
	{
		Jy t=new Jy();
		System.out.println(t.a);
		System.out.println(t.b);

	}
}

package string;

public class Contain {

	public static void main(String[] args) {
		String s1="I am jyoti";
		String s2="jyoti";
		System.out.println(s1.contains("am"));
		System.out.println(s1.contains("hii"));
		String s3=String.format("name is %s",s2);
		String s4=String.format("value is %f", 32.12);
		System.out.println(s3);
		System.out.println(s4);
		String s5=String.format( "name is %s", s2);
		System.out.println(s5);
		// TODO Auto-generated method stub

	}

}

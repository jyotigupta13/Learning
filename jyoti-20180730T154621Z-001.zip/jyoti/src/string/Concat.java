package string;

public class Concat {

	public static void main(String[] args) {
		int a=10;
		String s1=10+10+"Jyoti"+" "+"Gupta"+10+10;
		String s2="Jyoti ";
		String s3="Gupta";
		String s4="   jyoti   ";
		String b=String.valueOf(a);
		String s5=s2.intern();
		String s7=s3.replace("pta", "haha");
		System.out.println(s2.concat(s3));
		System.out.println(s1);
		System.out.println(s2.substring(2,4));
		System.out.println(s2.toUpperCase());
		System.out.println(s2.toLowerCase());
		System.out.println(s4.trim());
		System.out.println(s3.startsWith("G"));
		System.out.println(s3.endsWith("a"));
		System.out.println(s2.charAt(1));
		System.out.println(s2.length());
		System.out.println(s5);
		System.out.println(b+10);
		System.out.println(s7);
		// TODO Auto-generated method stub

	}

}

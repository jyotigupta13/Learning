package string;

public class Split {

	public static void main(String[] args) {
		String s="I am a pagal ladki haha";
		/*String[] s1=s.split("\\s");
		for(String sy:s1){
		System.out.println(sy);}  */
		for(String w:s.split("\\s",2)){
		System.out.println(w);}
		// TODO Auto-generated method stub

	}

}

package string;

public class Immutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="jyoti";
s1=s1.concat("gupta");
System.out.println(s1);
	}

}

package string;

public class GetByte {

	public static void main(String[] args) {
		String s1="ABCDEF";
		byte[] br=s1.getBytes();
		for(int i=0;i<br.length;i++){
			System.out.println(br[i]);
		}
		// TODO Auto-generated method stub

	}

}

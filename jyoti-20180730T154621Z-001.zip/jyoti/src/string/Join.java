package string;

public class Join {

	public static void main(String[] args) {
		String s="Hello";
		String s1=String.join(":","I","am","jyoti");
		System.out.println(s1);
		String s2="kya h pagal.Tum pagal.Bdi pagal";
		System.out.println(s2.lastIndexOf("a"));
		System.out.println(s2.replaceAll("\\s", ""));
				
		// TODO Auto-generated method stub

	}

}

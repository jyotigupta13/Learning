package string;

public class ToCharArray {

	public static void main(String[] args) {
		/*  String s1="girl";
		char[] s=s1.toCharArray();
		for(int i=0;i<s.length;i++){
		System.out.println(s[i]);   */
			String s2="  kya h pagalo   ";
			System.out.println(s2.trim()+"stpido");
		}
		// TODO Auto-generated method stub

	}



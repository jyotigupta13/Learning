package string;

public class Equals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="jyoti";
String s2="jyoti";
String s3= new String("jyoti");
String s4="gupta";
String s5="JYOTI";
System.out.println(s1.equals(s2));
System.out.println(s1.equals(s3));
System.out.println(s1.equals(s4));
System.out.println(s1==s2);
System.out.println(s1==s3);
System.out.println(s1.equalsIgnoreCase(s5));
System.out.println(s1.compareTo(s2));
System.out.println(s4.compareTo(s1));
System.out.println(s1.compareTo(s5));
	}

}

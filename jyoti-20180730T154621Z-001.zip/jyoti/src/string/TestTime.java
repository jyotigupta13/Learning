package string;

public class TestTime {
	public static String stringMethod(){
		String s1="Jyoti";
	
	for(int i=0;i<1000;i++){
		s1=s1+"gupta";
		}
	return s1;
}
	public static String stringBufferMethod(){
		StringBuffer s2=new StringBuffer("Jyoti");
		for(int i=0;i<1000;i++){
			s2.append("gupta");}
			return s2.toString();
		}
		public static void main(String[] args) {
		long st=System.currentTimeMillis();
		stringMethod();
		System.out.println("StringTime"+(System.currentTimeMillis()-st)+"ms");
		st=System.currentTimeMillis();
		stringBufferMethod();
		System.out.println("StringBufferTime"+(System.currentTimeMillis()-st)+"ms");
		
		// TODO Auto-generated method stub

	}

}

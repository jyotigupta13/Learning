package string;

public class Simple {

	public static void main(String[] args) {
		String s1="jyoti";
		char[] ch={'a','b','c'};
		String s2=new String(ch);
		String s3=new String("hii");
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		// TODO Auto-generated method stub

	}

}

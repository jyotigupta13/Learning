package string;

public class Capacity {

	public static void main(String[] args) {
		StringBuffer s1=new StringBuffer();
		s1.capacity();
		System.out.println(s1.capacity());
		s1.insert(0,"jyoti");
		System.out.println(s1);
		System.out.println(s1.capacity());
		s1.insert(5, "My Name is Jyoti hahahahahaha");
		System.out.println(s1);
		System.out.println(s1.capacity());
		s1.ensureCapacity(18);
		System.out.println(s1.capacity());
		s1.delete(0, 32);
		System.out.println(s1);
		System.out.println(s1.capacity());
		// TODO Auto-generated method stub

	}

}


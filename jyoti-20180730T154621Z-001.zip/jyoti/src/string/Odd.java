package string;

public class Odd {

	public static void main(String[] args) {
		String j="I am jyoti gupta from gkp";
		for(int i=0;i<=j.length()-1;i++){
			if(i%2!=0){
				System.out.println("charAt "+i+" place "+j.charAt(i));
			}
		}
		// TODO Auto-generated method stub

	}

}

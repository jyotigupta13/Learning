package string;

public class HashCode {
	public static void main(String[] args) {
		System.out.println("String");
		String s1="Jyoti";
		System.out.println(s1.hashCode());
		s1=s1+"Gupta";
		
		System.out.println(s1.hashCode());
		System.out.println("StringBuffer");
		StringBuffer s2=new StringBuffer("Jyoti");
		System.out.println(s2.hashCode());
		s2.append("Gupta");
		System.out.println(s2.hashCode());
		
		

	}

}

package string;

public class GetChar {

	public static void main(String[] args) {
		String s1="I am jyotiam";
		char[] ch=new char[4];
				s1.getChars(2,6,ch,0);
				try{
		System.out.println(ch);
				}
				catch(Exception e){System.out.println(e);}
				System.out.println(s1.indexOf("am",5));
				String s2="jyoti";
				String s3="";
				System.out.println(s3.isEmpty());
		// TODO Auto-generated method stub

	}

}

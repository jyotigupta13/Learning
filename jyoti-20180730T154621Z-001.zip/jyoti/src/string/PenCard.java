package string;

public  class PenCard {
     int rollno;
     String name;
     PenCard(int rollno,String name){
    	 this.rollno=rollno;
    	 this.name=name;
     }
     public String toString(){
    	 return rollno+" "+name;
     }
	public static void main(String[] args) {
		PenCard s1=new PenCard(101,"jyoti");
		System.out.println(s1);
		
		// TODO Auto-generated method stub

	}

}

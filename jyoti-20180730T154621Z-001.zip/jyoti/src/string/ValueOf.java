package string;

public class ValueOf {

	public static void main(String[] args) {
		int x=10;
		String s=String.valueOf(x);
		System.out.println(s+10);
		// TODO Auto-generated method stub

	}

}


public class InfiniteWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		while(true){
			System.out.println("infinite");
		}

	}

}

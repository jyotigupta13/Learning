/*package packag;
import java.awt.frame;
import java.util.Date;
import java.awt.Butten;

public class Temp {
public static void main(String[] a)
{
	frame f=new frame();
	Date d=new Date();
	Butten b=new Butten();
}
}
*/
/*package packag;
public class A{
	public void message(){System.out.println("j"); 
}*/
package packag;
import faltu.Print;
import jyoti.Operator.*;
 class B {
void j(){
	System.out.println("j");
}
	public static void main(String[] args) {
		Test obj=new Test();
		Print njg=new Print();
		Logical hgvs=new Logical();
		//obj.message();
	}
		// TODO Auto-generated method stub

	}



package instanceOf;
class Paa{
	
}
public class DownCast extends Paa {
static void method(Paa s){
	if (s instanceof DownCast){
		DownCast d=(DownCast)s;
		System.out.println("downcast");
	}
}
	public static void main(String[] args) {
		Paa s=new DownCast();
		DownCast.method(s);
		// TODO Auto-generated method stub

	}

}

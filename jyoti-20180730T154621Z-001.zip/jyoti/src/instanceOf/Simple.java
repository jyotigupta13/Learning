package instanceOf;

public class Simple {
	

	public static void main(String[] args) {
		Simple s1=new Simple();
		System.out.println(s1 instanceof Simple);
		// TODO Auto-generated method stub

	}

}

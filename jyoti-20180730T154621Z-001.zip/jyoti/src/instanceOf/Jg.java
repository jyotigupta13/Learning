package instanceOf;
class Pa{}
public class Jg extends Pa {

	public static void main(String[] args) {
		Jg s=new Jg();
		System.out.println(s instanceof Pa);
		// TODO Auto-generated method stub

	}

}

package abstrac;
interface ABC{
	void run();
}
interface BCD{
	void see();
}
public class MultipleInhari implements ABC,BCD {
public void run(){
	System.out.println("run");
	
}
public void see(){
	System.out.println("see");
}
	public static void main(String[] args) {
		MultipleInhari s1=new MultipleInhari();
		s1.run();
		s1.see();
		// TODO Auto-generated method stub

	}

}

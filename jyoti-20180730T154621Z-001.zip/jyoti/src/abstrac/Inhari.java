package abstrac;
interface AS{
	void run();
}
interface BS extends AS{
	void see();
}
public class Inhari implements BS {
	public void run(){
		System.out.println("run");
	}
	public void see(){
		System.out.println("see");
	}

	public static void main(String[] args) {
		Inhari s1=new Inhari();
		s1.run();
		s1.see();
		// TODO Auto-generated method stub

	}

}

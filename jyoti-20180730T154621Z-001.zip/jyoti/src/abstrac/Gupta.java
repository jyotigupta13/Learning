package abstrac;
abstract class A{
	abstract void run();
	
}

public class Gupta extends A {
	void run(){
		System.out.println("jyoti");
	}

	public static void main(String[] args) {
		A s1=new Gupta();
		s1.run();
		// TODO Auto-generated method stub

	}

}

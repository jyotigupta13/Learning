package abstrac;
interface AB{
	void a();
	void b();
	void c();
	void d();
}
abstract class B implements AB{
	public void a(){
		System.out.println("jy");
	}
}
public class TestA extends B {
	public void b(){
		System.out.println("b");
	}
	public void c(){
		System.out.println("c");
	}
	public void d(){
		System.out.println("d");
	}

	public static void main(String[] args) {
		AB s1=new TestA();
		s1.a();
		s1.b();
		s1.c();
		s1.d();
		// TODO Auto-generated method stub

	}

}

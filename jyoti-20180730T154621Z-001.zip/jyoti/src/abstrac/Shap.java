package abstrac;
abstract class Shape{
	Shape(){
		System.out.println("hi");
	}
	abstract void draw();
	void j(){System.out.println("j");
}
}	
class Ractangle extends Shape{
	void draw(){
		System.out.println("ractangle");
	}
}
class Circle extends Shape{
	void draw(){
		System.out.println("circle");
		
	}
}
public class Shap {

	public static void main(String[] args) {
		Shape s1;
		s1=new Ractangle();
		s1.draw();
		s1=new Circle();
		s1.draw();
		s1.j();
		// TODO Auto-generated method stub

	}

}

package jyoti;

public class Currentthread extends Thread{
	public void run(){
		System.out.println(Thread.currentThread().getName());
	}

	public static void main(String[] args) {
		Currentthread s1=new Currentthread();
		s1.start();
		// TODO Auto-generated method stub

	}

}
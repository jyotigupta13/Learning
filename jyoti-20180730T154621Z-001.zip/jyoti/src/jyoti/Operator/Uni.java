package jyoti.Operator;

public class Uni {
public static void main(String[] arg){
	int a=11;
	int b=-10;
	boolean c=true;
	boolean d=false;
	System.out.println(~a);
	System.out.println(~b);
	System.out.print(!c);
	System.out.println(!d);
	
}
}

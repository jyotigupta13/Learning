package jyoti.Operator;

public class Simple {

}

package jyoti.Operator;

public class Arithmatic {
	public static void main(String[] args){
		int a=8;
		int b=10;
		int c=8;
		System.out.println(b+c);
		System.out.println("a-b="+(a-b));
		System.out.println(a*b);
		System.out.println(a%b);
		System.out.println(a/b);
	}

}

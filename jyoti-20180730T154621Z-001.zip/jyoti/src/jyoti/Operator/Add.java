package jyoti.Operator;

public class Add {
public static void main(String[] ar){
	System.out.println("Hello");
}
}

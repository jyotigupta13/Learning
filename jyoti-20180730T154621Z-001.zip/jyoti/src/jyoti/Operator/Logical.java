package jyoti.Operator;

public class Logical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10;
int b=5;
int c=15;
System.out.println(a<b&&b<c);
System.out.println(a<b&b<c);

	}

}

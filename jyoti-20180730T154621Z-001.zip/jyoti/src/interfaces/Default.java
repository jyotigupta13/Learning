package interfaces;
interface S{
	void run();
	default void see(){System.out.println("body");}
	static int cube(int n){
		return n*n*n;
	}
}
class D implements S{
	public void run(){
		System.out.println("run");
	}
}
public class Default {

	public static void main(String[] args) {
		S s1=new D();
		s1.run();
		s1.see();
		System.out.println(S.cube(4));
		// TODO Auto-generated method stub

	}

}

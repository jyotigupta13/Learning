package interfaces;
interface Jyoti{}
class A implements Jyoti{
	public void A(){
		System.out.println("a");
	}
}
class C implements Jyoti{
	public void C(){
		System.out.println("c");
	}
}
public class B {
    void B(Jyoti s){
    	if (s instanceof A){  //upcasting
    		A a=(A)s;//downcasting
    		a.A();
    	}
    		if(s instanceof C){
    			C c=(C)s;
    			c.C();
    		
    	}
    }
	public static void main(String[] args) {
    	Jyoti s=new C();
    	B s1=new B();
    	s1.B(s);
		// TODO Auto-generated method stub

	}

}

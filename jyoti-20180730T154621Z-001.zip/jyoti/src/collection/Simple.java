package collection;
import java.util.*;
public class Simple {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		list.add("jyoti");
		list.add("gupti");
		list.add("jyoti");
		
		Iterator it=list.iterator();
		while(it.hasNext()){
			System.out.println("broe"+it.next());
		}
		Iterator it1=list.iterator();
		while(it1.hasNext()){
			if(it1.next().equals("jyoti")){
				it1.remove();
				break;
			}
		}
		Iterator it2=list.iterator();
		while(it2.hasNext()){
			System.out.println("after : "+it2.next());
		}

	}

}

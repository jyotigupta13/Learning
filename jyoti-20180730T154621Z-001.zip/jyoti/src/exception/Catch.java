package exception;

public class Catch {

	public static void main(String[] args) {
		try {
			int data=10/0;
		}
		catch(ArithmeticException e){
			System.out.println(e);
		
		}
		System.out.println("this is print");
		
		// TODO Auto-generated method stub

	}

}

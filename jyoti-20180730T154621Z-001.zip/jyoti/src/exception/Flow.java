package exception;

public class Flow {
	void A(){
		int data=10/0;
	}
	void B(){
	   A();
	}
void C(){
	try{
	B();
	}
	catch(Exception e){System.out.println("jyoti");}
}
	public static void main(String[] args) {
		Flow s1=new Flow();
		s1.C();
		// TODO Auto-generated method stub

	}

}

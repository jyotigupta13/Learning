package exception;

public class Simple {

	public static void main(String[] args) {
		int d[]=new int[5];
		try {
			System.out.println("j");
			try{
			System.out.println(d[5]);
			}catch(Exception e){
				System.out.println(e);
			}
			
			System.out.println("sdfsdsdcdsssc");
		} catch (NumberFormatException e) {
			System.out.println(e);
		}
		
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("nsfdjf");
	}

}

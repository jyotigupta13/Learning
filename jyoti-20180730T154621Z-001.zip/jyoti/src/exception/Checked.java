package exception;
class Pa{
	void msg(){System.out.print("j");
	}
}
public class Checked extends Pa {
	void msg() throws ArithmeticException{
		System.out.println("g");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Pa s1=new Checked();
s1.msg();
	}

	}

package exception;

import java.io.IOException;

public class NotFlow {
	void A(){
	try {
		throw new java.io.IOException("not valid");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
    void B(){
    	A();
    }
    void C(){
    	try{
    	B();
    	}
    	catch(Exception e){System.out.println("rd");}
    }
	public static void main(String[] args) {
		NotFlow s1=new NotFlow();
		s1.C();
		System.out.println("hahaha");
		// TODO Auto-generated method stub

	}

}

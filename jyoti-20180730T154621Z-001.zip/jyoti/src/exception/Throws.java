package exception;
import java.io.IOException;
public class Throws {
	void A() throws IOException{
		throw new IOException("not valid");
	}
	void B()throws Exception{
		A();
	}
	
	void C(){
		try{
		B();
	}
	catch(Exception e){
		System.out.println("a");
	}}

	public static void main(String[] args) {
		Throws s1=new Throws();
				s1.C();
		// TODO Auto-generated method stub
	}
	}



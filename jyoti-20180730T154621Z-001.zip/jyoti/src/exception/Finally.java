package exception;

public class Finally {

	public static void main(String[] args) {
		try{
			int data= 10/0;
			System.out.println(data);
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
			
		}
		finally{
			System.out.println("jyoti");
		}
		System.out.println("jyotinvckj");
		// TODO Auto-generated method stub
		System.exit(0);

	}

}

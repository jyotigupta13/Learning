package exception;
class InvalidAgeException extends Exception{
	InvalidAgeException(String d){
		super(d);
	}
}

public class InvalidException  {
	void age(int age) throws Exception{
		
	
	if(age<20){
	throw new InvalidAgeException("not valid");
	}
	else{
		System.out.println("valid");
	}
	}
	public static void main(String[] args) {
		InvalidException s1=new InvalidException();
		try{
		s1.age(21);
		}
		catch(Exception e){System.out.println("haha");}
		System.out.println("jyoti");
		// TODO Auto-generated method stub

	}

}

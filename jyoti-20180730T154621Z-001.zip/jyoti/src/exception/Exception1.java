package exception;

public class Exception1 {
	static void age(int age){
		try{
		if(age<20){
			throw new ArithmeticException("not valid");}
		
			else
				System.out.println("valid");}
		catch(ArithmeticException e){System.out.println(e);}
		System.out.println("skdm");
		}
	

	public static void main(String[] args) {
		age(15);
		age(21);
		System.out.println("hahaa");
		
		
		// TODO Auto-generated method stub

	}

}

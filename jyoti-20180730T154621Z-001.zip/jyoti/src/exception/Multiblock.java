package exception;

public class Multiblock {

	public static void main(String[] args) {
		try{
			int a[]=new int [5];
			a[5]=10/0;
		}
		
	
		catch(Exception e){
			System.out.println("print2");
		}
			
		System.out.println("jyoti");
		}
		// TODO Auto-generated method stub

	}



package exception;

public class NestedCatch {
      
	public static void main(String[] args) {
		try{
			
		
			try{
				System.out.println("exception");
				int data =10/0;
			}
			catch(ArithmeticException e){
				System.out.println(e);
				e.printStackTrace();
			}
			try{
				int a[]=new int[5];
				a[5]=10;
			
			}
				catch(ArrayIndexOutOfBoundsException f){
					System.out.println(f);
				}
			System.out.println("j");
		}
			catch(ArithmeticException e){
				System.out.println("normal");
			}
			
			System.out.println("normal flow");
		
		// TODO Auto-generated method stub
		
	}

}

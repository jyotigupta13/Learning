package association;
class square{
	int square(int n){
		return n*n;
	}
	
}

public class Circle {
    square s;
    double PI=3.14;
    double area(int radius){
    	square s2=new square();
    	int rsquare=s2.square(radius);
    	return PI*rsquare;
    	}
	public static void main(String[] args) {
		Circle s1=new Circle();
		double result=s1.area(2);
		System.out.println(result);
		// TODO Auto-generated method stub

	}

}

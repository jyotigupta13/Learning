package association;

 class Bank {
	int rateinterest() {
		return 0;
	}
}

class SBI extends Simple {
	int rateinterest() {
		return 7;
	}
}

class ICI extends Simple {
	int rateinterest() {
		return 9;
	}
}

public class Simple {
	public static void main(String[] args) {
		SBI s1 = new SBI();
		ICI s2 = new ICI();
		System.out.println(s1.rateinterest());
		System.out.println(s2.rateinterest());
		// TODO Auto-generated method stub

	}

}

package association;

 class Bddress {
	String city,state,country; 
	public Bddress(String city,String state,String country){
		this.city=city;
		this.state=state;
		this.country=country;
	}
}
public class Empz{
	int id;
	String name;
	Bddress address;
	public Empz(int id,String name,Bddress address){
		this.id=id;
		this.name=name;
		this.address=address;
	}
	
	void display(){
		System.out.println(id+" "+name);
		System.out.println(address.city+" "+address.state+" "+address.country);
	}
	
	
	
	public static void main(String[] args) {
		Bddress s1=new Bddress("luck","bihar","australia");
		Bddress s2=new Bddress("gkp","up","India");
		
		Empz s3=new Empz(123,"jyoti",s1);
		Empz s4=new Empz(234,"gupta",s2);
		s3.display();
		s4.display();
		// TODO Auto-generated method stub

	}

}

package association;

class Bank1 {
	int getRateOfInterest() {
		return 0;
	}
}

class SBI1 extends Simple {
	int getRateOfInterest() {
		return 8;
	}
}

class ICICI extends Simple {
	int getRateOfInterest() {
		return 7;
	}
}

class AXIS extends Simple {
	int getRateOfInterest() {
		return 9;
	}
}

public class Copy {
	public static void main(String args[]) {
		SBI1 s = new SBI1();
		ICICI i = new ICICI();
		AXIS a = new AXIS();
		System.out.println("SBI Rate of Interest: " + s.getRateOfInterest());
		System.out.println("ICICI Rate of Interest: " + i.getRateOfInterest());
		System.out.println("AXIS Rate of Interest: " + a.getRateOfInterest());
	}
}

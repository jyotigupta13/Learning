package threading;

public class Periority extends Thread { 
       public void run(){
    	   for(int i=1;i<=5;i++){
    	   System.out.println("Thread name : "+Thread.currentThread().getName() + " "+ Thread.currentThread().getPriority() );
    	  // System.out.println("Thread Periority : "+Thread.currentThread().getPriority());
       }}
	public static void main(String[] args) {
		Periority s1=new Periority();
		Periority s2=new Periority();
		s1.setPriority(MIN_PRIORITY);
		s2.setPriority(MAX_PRIORITY);
		s1.start();
		s2.start();
		// TODO Auto-generated method stub

	}

}

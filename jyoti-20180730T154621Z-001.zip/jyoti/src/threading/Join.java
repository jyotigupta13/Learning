package threading;

public class Join extends Thread {
	public void run(){
		for(int i=1;i<=5;i++){
			try{
				Thread.sleep(500);}
	catch(Exception e){System.out.println(e);		
	}
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		Join s1=new Join();		
		Join s2=new Join();
		Join s3= new Join();
		s1.start();
		try{
			s1.join();}
		catch(Exception e){System.out.println(e);}
		s2.start();
		s3.start();
		}
	}


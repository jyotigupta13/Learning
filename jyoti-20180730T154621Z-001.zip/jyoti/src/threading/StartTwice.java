package threading;

public class StartTwice extends Thread {
	public void run(){
		System.out.println("thread");
	}

	public static void main(String[] args) {
		StartTwice s1=new StartTwice();
		s1.start();
		s1.start();
		
	}

}

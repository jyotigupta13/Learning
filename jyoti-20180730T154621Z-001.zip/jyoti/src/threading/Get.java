package threading;

public class Get extends Thread {
	public void run(){
		System.out.println("thrad..");
			
		}
	

	public static void main(String[] args) {
		Get s1=new Get();
		Get s2=new Get();
		System.out.println("name of s1:"+s1.getName());
		System.out.println("name of s2:"+s2.getName());
		System.out.println("id of s1:"+s1.getId());
		s1.start();
		s2.start();
s1.setName("laloo");
System.out.println("change name of s1:"+s1.getName());
		// TODO Auto-generated method stub

	}

}

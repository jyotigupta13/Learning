package threading;

public class ExtendThread implements Runnable {
	public void run(){
		System.out.println("threzd");
	}
	public static void main(String[] a) {
		ExtendThread s=new ExtendThread();
		Thread t=new Thread(s);
		t.start();
		
	}

}

package threading;

public class Simple extends Thread {
	public void run(){
    /*for(int i=1;i<5;i++){
    	try{Thread.sleep(500);}catch(Exception e){System.out.println(e);}
    	System.out.println(i);
     }*/
     System.out.println("running");}
	public static void main(String[] args) {
		Simple s1=new Simple();
		Simple s2=new Simple();
		Simple s3=new Simple();
		System.out.println(s1.currentThread().getName());
		System.out.println((s2.getName()));
		
		/*s1.start();
		try{
		s1.join(1500);
		}
		catch(Exception e){System.out.println(e);} */
		s2.start();
		s3.start();
		s2.setName("pagal");
		System.out.println(s2.getName());
		
		
		
		// TODO Auto-generated method stub

	}

}

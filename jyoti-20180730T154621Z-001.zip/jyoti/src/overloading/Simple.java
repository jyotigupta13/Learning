package overloading;
class jyoti{
	void j(int x,int y){
	int	ractangle=x*y;
	System.out.println(ractangle);
	}
	void j(int x){
		int square=x*x;
		System.out.println(square);
	}
}


public final class Simple {

	public static void main(String[] args) {
		jyoti s1=new jyoti();
		s1.j(10,20);
		s1.j(5);
		// TODO Auto-generated method stub

	}

}

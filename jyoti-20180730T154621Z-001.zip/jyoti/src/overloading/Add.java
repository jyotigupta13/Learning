package overloading;
class J{
	static int jyoti(int x,int y){return x+y;}	
	static int jyoti(int x,int y,int z){return x+y+z;}
	
	}


public class Add {

	public static void main(String[] args) {
		System.out.println(J.jyoti(10,20));
		System.out.println(J.jyoti(1, 2, 3));
	
		// TODO Auto-generated method stub

	}

}

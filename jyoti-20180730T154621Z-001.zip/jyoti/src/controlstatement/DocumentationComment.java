package controlstatement;

/**
 * @author Vandana
 * vjhdfj
 */
public class DocumentationComment {

	public static void main(String[] args) {
		
		int i=10;
		
System.out.println(i);
	}

}

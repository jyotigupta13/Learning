package controlstatement;

public class ForEach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={23,24,89,76,78};
		for(int i:arr){
			System.out.println(i);
		}

	}

}

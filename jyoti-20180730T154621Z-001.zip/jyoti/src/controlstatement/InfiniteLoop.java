package controlstatement;

public class InfiniteLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(;;){
			System.out.println("infinite loop");
		}

	}

}

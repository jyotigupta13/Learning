package stringBuffer;

public class Append {

	public static void main(String[] args) {
		StringBuffer s1=new StringBuffer("jyoti ");
		StringBuffer s=s1.append("gupta");
		System.out.println(s1);
		s1.insert(1, "ha");
		System.out.println(s1);
		s1.replace(1, 4, "kya");
		System.out.println(s1);
		s1.delete(1, 3);
		System.out.println(s1);
		s1.reverse();
		System.out.println(s1);
		// TODO Auto-generated method stub

	}

}

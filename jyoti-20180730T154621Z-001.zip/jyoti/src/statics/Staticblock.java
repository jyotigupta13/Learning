package statics;

public class Staticblock {
	

	public static void main(String[] args) {
		System.out.println("h");
	} 
	static{System.out.println("hii");}
		// TODO Auto-generated method stub

	}


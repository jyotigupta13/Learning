package statics;

public class WithStatic {
	static int count=0;
	WithStatic(){
		count++;
		System.out.println(count);
	}

	public static void main(String[] args) {
		WithStatic s1=new WithStatic();
		WithStatic s2=new WithStatic();
		// TODO Auto-generated method stub

	}

}

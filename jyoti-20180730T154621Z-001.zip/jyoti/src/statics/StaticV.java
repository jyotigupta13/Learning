package statics;

public class StaticV {
	int rollno;
	String name;
	static String college="ITS";
	
	StaticV(int i,String n){
		rollno=i;
		name=n;
	}
void display(){
	System.out.println(rollno+" "+name+" "+college);
}
	public static void main(String[] args) {
		StaticV s1=new StaticV(111,"Ram");
		StaticV s2=new StaticV(222,"Sam");
		s1.display();
		s2.display();
		
		// TODO Auto-generated method stub

	}

}

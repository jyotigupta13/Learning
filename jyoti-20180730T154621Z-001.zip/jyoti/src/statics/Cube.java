package statics;

public class Cube {
static int cube(int x){
	 return x*x*x; 
}
	public static void main(String[] args) {
		int result=Cube.cube(5);
		System.out.println(result);
		// TODO Auto-generated method stub

	}

}

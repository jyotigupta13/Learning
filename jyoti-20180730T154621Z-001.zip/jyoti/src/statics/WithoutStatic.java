package statics;

public class WithoutStatic {
	int count=0;
WithoutStatic(){
	count++;
	System.out.println(count);
}
	public static void main(String[] args) {
		WithoutStatic s1=new WithoutStatic();
		WithoutStatic s2=new WithoutStatic();
		
	}

}

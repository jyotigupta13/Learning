package statics;

class Withoutmain {
	static {
		System.out.println("jyoti");
		//System.exit(0);
	}
	
	
	
}
package statics;

public class Staticmethod {
	int rollno;
	String name;
	static String college="ITS";
	
	static void change(){
		college="BBD";
		}
	Staticmethod(int i,String n){
		rollno=i;
		name=n;
	}
  void display(){
	  System.out.println(rollno+" "+name+" "+college);
  }
  
 public static void main(String[] args) {
	 Staticmethod.change();
	 Staticmethod s1=new Staticmethod(111,"Ram");
	 Staticmethod s2=new Staticmethod(222,"Sam");
		s1.display();
	 s2.display();
		// TODO Auto-generated method stub

	}

}

package array;

public class Simple2 {

	public static void main(String[] args) {
		int a[]={10,2,3,4};
		for(int i=0;i<a.length;i++){
			System.out.println(a[i]);
		}
		
		// TODO Auto-generated method stub

	}

}

package array;

public class Copy {

	public static void main(String[] args) {
		char[] copyFrom={'a','b','c','d','e','f'};
		char[] copyTo=new char[7];
		System.arraycopy(copyFrom, 1, copyTo, 1, 5);
		System.out.println(new String(copyTo));
		
		// TODO Auto-generated method stub

	}

}

package array;

public class Get {

	public static void main(String[] args) {
		int arr[]={33,3,2,4};
		Class a=arr.getClass();
		String name=a.getName();
		System.out.println(name);
		
		// TODO Auto-generated method stub

	}

}

package array;

public class MultiArr {
	
	static void j(int a[][]){
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
			System.out.println( a[i][j]+" ");	
	}
		}
	}
	public static void main(String[] args) {
		int a[][]={{1,2,3},{2,3,4},{3,4,5}};
		MultiArr.j(a);
		// TODO Auto-generated method stub

	}

}

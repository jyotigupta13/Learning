package inheritance;
class Employee{
	void salary(){
		System.out.println("2000");
	}
}
class programmer extends Employee{
	void bonus(){
		System.out.println("1000");
	}
}
public class Employe {

	public static void main(String[] args) {
		programmer s1=new programmer();
		s1.bonus();
		s1.salary();
		// TODO Auto-generated method stub

	}

}

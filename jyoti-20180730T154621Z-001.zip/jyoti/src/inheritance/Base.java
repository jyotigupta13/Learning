package inheritance;

class Basee {
  int x;
  int y;
  void show(){
	  System.out.println(x);
	  System.out.println(y);
  }
}
class Child extends Basee{
	void get(int x,int y){
	System.out.println(x);
	this.y=y;
		
	}
}
class Base{
	public static void main(String[] ar){
	Child s1=new Child();
		s1.get(10,20);
		s1.show();
	}
}
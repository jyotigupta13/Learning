package inheritance;
class dadaji{
	int x=10;
	
}
class rase extends dadaji{
	int x=20;
}
class mhild extends rase{
	int x=30;
	void get(){
		System.out.println(x);
		System.out.println(super.x);
		System.out.println(((dadaji)this).x);
		System.out.println(((rase) this).x);
	}
}
public class Da {

	public static void main(String[] args) {
		mhild s=new mhild();
		s.get();
		System.out.println(((dadaji)s).x);
		// TODO Auto-generated method stub

	}

}

package inheritance;
class Papa{
	int x=10;
}
class bhild extends Papa{
	int x=20;
	void claa(){
		System.out.println(x);
		System.out.println(super.x);
		System.out.println(this.x);
	}
}
public class Tember {

	public static void main(String[] args) {
		bhild s1=new bhild();
		s1.claa();
		// TODO Auto-generated method stub

	}

}

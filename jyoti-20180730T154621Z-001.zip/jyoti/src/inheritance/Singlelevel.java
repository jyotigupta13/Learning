package inheritance;
class Animal{
	void eat(){
	System.out.println("eating");
}
}
class Dog extends Animal{
	void bark() {System.out.println("barking");
}
}
public class Singlelevel {

	public static void main(String[] args) {
		Dog s1=new Dog();
		s1.bark();
		s1.eat();
		// TODO Auto-generated method stub

	}
}

package faltu;

public class OverrideParent {
	
	void test(){
		
		System.out.println("Hello parent test");
	}
	

}

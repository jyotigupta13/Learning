package faltu;

public class This {
	int x=10;
	void show(int y){
		int x=20;
		System.out.println(this.x);
		System.out.println(y);
	}
	public static void main(String[] ar){
		This s1=new This();
		s1.show(20);
		System.out.println(s1.x);
	}

}

package faltu;

public class Print {

	public Print(){ 
		System.out.println("Constructjhjhor");
	}
	void add(){
		System.out.println("Add method");
	}
	
	public static void main(String[] s) {
		 Print p=new Print();
		 p.add();
	}
	
}

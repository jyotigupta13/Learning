package faltu;

public class Instance {
	{System.out.println("jyoti");}

	public static void main(String[] args) {
		Instance s1=new Instance();
		// TODO Auto-generated method stub

	}

}

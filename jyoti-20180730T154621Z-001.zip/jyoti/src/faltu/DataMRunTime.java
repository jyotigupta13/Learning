package faltu;
class Papa{
	int x=20;
}

public class DataMRunTime extends Papa {
	int x=10;
	public static void main(String[] ar){
	Papa s1=new DataMRunTime();
System.out.println(s1.x);
}
}
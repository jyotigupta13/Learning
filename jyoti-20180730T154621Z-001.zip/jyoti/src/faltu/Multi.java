package faltu;

public class Multi {
	int x=4;
	Multi(){
		System.out.println( x=2);
	};
	
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Multi s1=new Multi();
		System.out.println(s1.x);
    	     
       }
	}


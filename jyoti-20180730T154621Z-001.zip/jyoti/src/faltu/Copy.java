package faltu;

public class Copy {
	

	    public static void main(String args[]) {
	        int i=2;
	        do {
	            i++;
	        }
	        while(i < 0);
	        System.out.println(i);
	    }
	}
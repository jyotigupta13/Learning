package faltu;


	class Animal{  
		void eat(){System.out.println("eating");}  
		}  
		class Dog extends Animal{  
		void eat(){System.out.println("eating fruits");}  
		}  
		public class BabyDog extends Dog{  
		void eat(){System.out.println("drinking milk");}  
		public static void main(String args[]){  
		Animal a;  
		a=new Animal();
		a.eat();
		a=new Dog();
		a.eat();
		a=new BabyDog();  
		a.eat();   
		}  
		}  


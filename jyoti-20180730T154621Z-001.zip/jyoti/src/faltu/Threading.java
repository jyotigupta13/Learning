package faltu;
 public class Threading extends Thread {
	public void run(){
		System.out.println("this is thread");
	}

	public static void main(String[] args) {
		Threading w=new Threading();
		w.start();
		// TODO Auto-generated method stub

	}

}
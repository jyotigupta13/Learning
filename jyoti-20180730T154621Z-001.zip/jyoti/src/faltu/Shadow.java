package faltu;

public class Shadow {
	public static void main(String[] ABC){
		String s1= new String("Hello");
		String s2="Hello";
		String s3="Hello";
		String s4=new String("Hello");
		/*if(s1==s4){
			System.out.println("s1 and s4 are equals");
		}else{
			System.out.println("not equal");
		}*/
		System.out.println(s1.charAt(4));
		
	}
}

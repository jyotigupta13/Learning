package faltu;

public class OverrideTest extends OverrideParent {

	void test(){
		System.out.println("child test class");
	}
	
	public static void main(String[] args) {

		OverrideTest pa=new OverrideTest();
		pa.test();
	}

}

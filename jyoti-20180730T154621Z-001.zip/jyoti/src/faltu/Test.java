package faltu;

class Test{  
    int id;  
    String name;  
    Test(int i,String n){  
    id = i;  
    name = n;  
    }  
      
    Test(Test s){  
    id = s.id;  
    name =s.name;  
    }  
    void display(){System.out.println(id+" "+name);}  
   
    public static void main(String args[]){  
    Test s1 = new Test(111,"Karan");  
    Test s2 = new Test(s1);  
    s1.display();  
    s2.display();  
   }  
}  

package supe;
class Person{
	int id;
	String name;
	Person(int id,String name){
		this.id=id;
		this.name=name;
		
	}
}
public class Empl extends Person {
	String salary;
	Empl(int id,String name,String salary){
		super(id,name);
		this.salary=salary;
	}
	void display(){
	System.out.println(id+" "+name+" "+salary);
	}

	public static void main(String[] args) {
		Empl s1=new Empl(123,"jyoti","1000");
		s1.display();
	
		// TODO Auto-generated method stub

	}

}

package supe;

class Pa {
	String color = "white";

	Pa() {
		System.out.println("sheel");
	}

	void pa() {
		System.out.println("jyoti");
	}
}

class Child extends Pa {
	String color = "blue";

	Child() {
		super();
		System.out.println("shing");
	}

	void child(){
		System.out.println(color);
		System.out.println(super.color);}
		void pa(){
			System.out.println("childmathd");}
			void na(){
				pa();
				super.pa();
			}
	
}

public class Use {

	public static void main(String[] args) {
		Child s1 = new Child();
		Pa s2 = new Pa();
		s1.child();
		// TODO Auto-generated method stub

	}

}

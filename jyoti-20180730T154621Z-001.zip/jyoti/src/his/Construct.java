package his;
class B{
	 B(){
		 System.out.println("j");
		 }
	
	 B(int x){
		this();
		System.out.println("y"); 
		}
}

public class Construct {

	public static void main(String[] args) {
		B s1=new B(20);
		
		// TODO Auto-generated method stub

	}

}

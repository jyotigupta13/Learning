package his;
class Student{
	int rollno;
	String name;
	String id;
	Student(int rollno,String name){
		this.rollno=rollno;
		this.name=name;
		
	}
	Student(int rollno,String name,String id){
		this(rollno,name);
		this.id=id;
	}


void display(){System.out.println(rollno+" "+name+" "+id);}
	
}

public class Variable {

	public static void main(String[] args) {
		Student s1=new Student(11,"jyoti");
		Student s2=new Student(111,"aaj","rom");
		s1.display();
		s2.display();
		// TODO Auto-generated method stub

	}

}

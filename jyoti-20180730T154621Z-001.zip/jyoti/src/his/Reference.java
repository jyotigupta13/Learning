package his;

public class Reference {
	void jhki(){
	System.out.println(this);	
	}
	public static void main(String[] args) {
		Reference s1=new Reference();
		System.out.println(s1);
		s1.jhki();
		// TODO Auto-generated method stub

	}

}

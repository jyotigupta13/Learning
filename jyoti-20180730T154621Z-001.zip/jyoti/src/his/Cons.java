package his;
class C{
	C(){
		this(20);
	System.out.println("h");
	}
	C(int x){
		System.out.println("g");
	}
}

public class Cons {

	public static void main(String[] args) {
		C s1=new C();
		// TODO Auto-generated method stub

	}

}

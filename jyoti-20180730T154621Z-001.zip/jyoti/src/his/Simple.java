package his;
class Anm{
void method1(){
	int u=this.method2();
	System.out.println(u);
}
int method2(){
	int x=10;
	int y=5;
	int z=x+y;
	return z;
}
}
public class Simple {
	public static void main(String[] ar){
		Anm s1=new Anm();
		Anm s2=new Anm();
		s1.method1();
	}
}

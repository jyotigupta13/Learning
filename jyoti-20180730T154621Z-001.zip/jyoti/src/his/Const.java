package his;
class A{
	Const obj;
	A(Const obj){
		this.obj=obj;
		
	}
	void display(){
		System.out.println(obj.z);
	}
	
}
public class Const {
    int z=10;
    Const(){
    	A s2=new A(this);
    	s2.display();
    }
	public static void main(String[] args) {
		Const s1=new Const();
	
		// TODO Auto-generated method stub

	}

}

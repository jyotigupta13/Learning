package his;

class Abx {
	void A(){
		System.out.println("j");
		this.B(20);
	}
void B(int x){
	System.out.println("y");
}
}
public class Object{
	public static void main(String[] args) {
		Abx a=new Abx();
		a.A();
		// TODO Auto-generated method stub

	}

}

package his;
class S{
	S jyoti(){
		return this;
	}
	void gupta(){
		System.out.println("G");
	}
}

public class Thi {
	
	public static void main(String[] args)
	{
		new S().jyoti().gupta();
		// TODO Auto-generated method stub

	}

}

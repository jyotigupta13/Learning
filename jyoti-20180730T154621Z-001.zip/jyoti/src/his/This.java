package his;
class G{
	void Ar(G obj){
		System.out.println("j");
	}
	void Jg(){
		System.out.println("h");
		Ar(this);
	
	}
}

public class This {
      public static void main(String[] ar){
    	 
    	  G s1=new G();
    	  s1.Jg();
    	  
    	  
      }
}

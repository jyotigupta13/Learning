import java.util.Scanner;
public class PrimePrint {

	public static void main(String[] args) {
		int a=0,i,j=0,sum=0,count=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no : ");
		int n=sc.nextInt();
		for(i=1;i<n;i++) {
			for(j=2;j<i;j++) {
			if(i%j==0) {
				count=0;
				break;
			}
			else {
				count=1;
			}
			}
			
		
		if(count==1) {
			System.out.println(i);
			}
		}

 
	}

}

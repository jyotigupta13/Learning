import java.util.Scanner;
public class TransposeMatrix {

	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of row of matrix : ");
		int row=sc.nextInt();
        System.out.println("Enter size of column of matrix : ");
        int col=sc.nextInt();
        int a[][]=new int[row][col];
        int transpose[][]=new int[col][row];
        System.out.println("Enter element in matrix a : ");
        for(i=0;i<row;i++) {
        	for(j=0;j<col;j++) {
        		a[i][j]=sc.nextInt();
        	}
        }
		/*
		 * for(i=0;i<row;i++) { for(j=0;j<col;j++) { transpose[j][i]=a[i][j]; } }
		 */
        
        for(i=0;i<col;i++) {
        	for(j=0;j<row;j++) {
        		transpose[i][j]=a[j][i];
        	}
        }
        System.out.println("original matrix are : ");
        for(i=0;i<row;i++) {
        	for(j=0;j<col;j++) {
        		System.out.print(a[i][j] + "\t");
        	}
        	System.out.println();
        }
        System.out.println("transpose matrix are : ");
        for(i=0;i<col;i++) {
        	for(j=0;j<row;j++) {
        		System.out.print(transpose[i][j] + "\t");
        	}
        	System.out.println();
        }
        
	}

}

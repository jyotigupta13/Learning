import java.util.Scanner;
public class Palindrom {

	public static void main(String[] args) {
		int temp,number,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no to check palindrom");
		int s=sc.nextInt();
		temp =s;
		while(s>0) {
		
		number=s%10;
		sum=(sum*10)+number;
		s=s/10;
		}
		if(temp==sum) {
			System.out.println("palindrom");
			
		}
		else {
			System.out.println("not palindrom");
			
		}
		
		
		
	}

}

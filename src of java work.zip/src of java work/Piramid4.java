
public class Piramid4 {

	public static void main(String[] args) {
		char First='A',Last='E';
        char i,j;
        for(i=First;i<=Last;++i) {
        	for(j=First;j<=i;++j) {
        		System.out.print(i + " ");
        	}
        	System.out.println();
        }
	}

}

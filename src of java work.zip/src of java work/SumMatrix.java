import java.util.Scanner;
public class SumMatrix {

	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter row and column of matrix : ");
		int n=sc.nextInt();
		int m=sc.nextInt();
		
		int a[][]=new int[n][m];
		int b[][]=new int[n][m];
		int sum[][]=new int[n][m];
		System.out.println("Enter element in a array : ");
		for(i=0;i<n;i++) {
			for(j=0;j<m;j++) {
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("Enter element in b array : ");
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				b[i][j]=sc.nextInt();
			}
		}
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				sum[i][j]=a[i][j]+b[i][j];
			}
		}
		System.out.println("sum of matrix is : ");
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) {
		
        System.out.print(sum[i][j] + "\t");
			}
			System.out.println();
		}
	}

}

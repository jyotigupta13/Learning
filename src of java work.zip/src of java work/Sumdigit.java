import java.util.Scanner;
public class Sumdigit {

	public static void main(String[] args) {
		int b,sum=0;
	
	 Scanner sc=new Scanner(System.in);
	 System.out.println("enter your digit");
	 int a=sc.nextInt();
	 while(a>0) {
	    b=a%10;
	    sum=sum+b;
	     a=a/10;

	}
	 System.out.println("sum of digit = " + sum);

}
}
import java.util.Scanner;
public class UniqueString {
     public static void main(String[] arg) {
    	 int i;
    	 Scanner sc=new Scanner(System.in);
    	 System.out.println("Enter string : ");
    	 String s=sc.nextLine();
    	 String temp="";
    	 for(i=0;i<s.length();i++) {
    		 if(temp.indexOf(s.charAt(i))==-1) {
    			 temp=temp+s.charAt(i);
    		 }
    		 
    	 }
    	 System.out.println("unique string is : " + temp);
     }
}

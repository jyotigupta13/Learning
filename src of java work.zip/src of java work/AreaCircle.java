import java.util.Scanner;
public class AreaCircle {

	public static void main(String[] args) {
		double area;
		Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius : ");
		int r=sc.nextInt();
		area=3.14*r*r;
		System.out.println("area : " + area);
		double parimeter=2*Math.PI*r;
		System.out.println("parimeter : " + parimeter);
		
		
		System.out.println("enter length of ractangle : ");
		int l=sc.nextInt();
		System.out.println("enter width of ractancle : ");
		int w=sc.nextInt();
		area=l*w;
		System.out.println("area of ractangle : " + area);
		 parimeter=2*(l+w);		
		 System.out.println("parimeter of triangle : " + parimeter);
		 
		 
		 System.out.println("Enter a : ");
		 int a=sc.nextInt();
		 System.out.println("Enter b : ");
		 int b=sc.nextInt();
		 System.out.println("Enter c : " );
		 int c=sc.nextInt();
		 parimeter=a+b+c;
		 System.out.println("Parimeter of triangle : " + parimeter);
	}

}

import java.util.Scanner;

public class Argument {

	public static void main(String[] args) {
		int t1=0,t2=1,sum;
		Scanner sc = new Scanner(System.in); 
		  
        // String input 
        String name = sc.nextLine(); 
  
        System.out.println("argument" + name);
        int n = Integer.parseInt(name);
        for(int i=0;i<=n;++i) {
        	System.out.print(t1 + "+");
        	sum=t1+t2;
        	t1=t2;
        	t2=sum;
        }

	}

}

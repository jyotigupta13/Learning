import java.util.Scanner;
public class ReverseNo {

	public static void main(String[] args) {
		int a=0,i,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		System.out.println("reverse number : ");
		int temp=n;
		while(n>0) {
        a=n%10;
        System.out.print(a);
        sum=(sum*10)+a;
        n=n/10;

		}
		System.out.println();
		if(temp==sum) {
			System.out.println("palindrom");
			
		}
		else {
			System.out.println("not palindrom");
		}
	}

}


public class Insertion {

	public static void main(String[] args) {
		int i,j,temp;
		int a[]= {5,3,6,9,8,2,1,7};
		
		System.out.println("unsorted list is : " + "{5,3,6,9,8,2,1,7}");
		
		for(i=1;i<a.length;i++) {
			for(j=i;j>0;j--) {
				if(a[j]<a[j-1]){
					temp=a[j];
					a[j]=a[j-1];
					a[j-1]=temp;
				}
		
			}
		}
		System.out.print("sorted list are : {");
		  for(i=0;i<a.length;i++) {
			System.out.print(a[i] + ",");
		  }
		  System.out.print("}");
		
		
	}

}

import java.util.Scanner;
public class ArraySecondSmall {

	public static void main(String[] args) {
		int min,i,secondmin;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of element in array");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter element : ");
		for(i=0;i<n;i++) {
		   a[i]=sc.nextInt();	
		}
		min=a[0];
		secondmin=a[1];
		for(i=0;i<n;i++) {
			if(min>a[i]) {
				secondmin=min;
				min=a[i];
			}
			else if(a[i]<secondmin && a[i]!=min){
				secondmin=a[i];
			}
		}
		System.out.println("second minimum : " + secondmin);
		

	}

}

import java.util.Scanner;
public class BinaryToOctal {

	public static void main(String[] args) {
		int p=0,rem,j;
		double decimal=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter binary number : ");
		int n=sc.nextInt();
        while(n!=0) {
        	rem=n%10;
        	decimal=decimal+rem*Math.pow(2,p);
        	n=n/10;
        	++p;
        }
        double octal[]=new double[100];
        System.out.println("decimal conversion is : " + decimal);
        int i=0;
        while(decimal>=1) {
        	octal[i]=decimal % 8;
        	decimal=decimal/8;
        	++i;
        }
        System.out.println("Octal conversion is : ");
        for(j=i-1;j>=0;j--) {
        	System.out.println(octal[j]);
        }
	}

}

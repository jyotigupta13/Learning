import java.util.Scanner;
public class ReverseRec {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		Reverse(n);

	}
	static void  Reverse(int n){
		  if(n<10) {
			  System.out.print(n);
			  return;
		  }
		  else {
			  System.out.print(n%10);
			  Reverse(n/10);
		  }
	  }

}

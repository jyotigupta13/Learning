import java.util.Scanner;
public class ArraySt {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s;
		//s=sc.nextLine();
		System.out.println("reverse of swift: ");
		char a[]= {'s','w','i','f','t'};
		int n=a.length;
		for(int i=a.length-1;i>=0;i--) {
      System.out.print(a[i]);
		}
       
        
	}

}

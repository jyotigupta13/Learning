
public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int a=20,c=0,i;
       for(i=1;i<=20;i++) {
    	   if(a%i==0)
    		   c=c+1;
       }
       if(c==2) {
    	   System.out.println("no. is prime");
       }
       else
    	   System.out.println("no.is not prime");
	}

}

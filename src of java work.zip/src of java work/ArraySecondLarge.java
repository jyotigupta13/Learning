import java.util.Scanner;
public class ArraySecondLarge {

	public static void main(String[] args) {
		int i,max,secondLargest;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of element in an array : ");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter element : ");
		for(i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		max=a[0];
		secondLargest=a[1];
		for(i=0;i<n;i++) {
			if(max < a[i]) {
				secondLargest=max;
				max=a[i];
			}
			
			  else if (a[i] > secondLargest && a[i]!= max) { 
				  secondLargest = a[i];
			  
			  }
			 
		}
		System.out.println("second largest : " + secondLargest);

	}

}

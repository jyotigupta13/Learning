import java.util.Scanner;
public class Average {

	public static void main(String[] args) {
		float average;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first no");
		int a=sc.nextInt();
		System.out.println("Enter second no");
		int b=sc.nextInt();
	    int  sum=a+b;
		 average=(float)((a+b)/2);
		System.out.print("average = " + average);

	}

}

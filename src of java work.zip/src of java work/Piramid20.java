
public class Piramid20 {

	public static void main(String[] args) {
		int i,j;
		for(i=1;i<=7;i++) {
			
			for(j=1;j<=i ;j++) {
				if(j%2==0) {
					System.out.print(0);
				}
				else
				{
					System.out.print(1);
				}
				
			}
			System.out.println();
			/*
			 * num=0; for(j=1;j<=i;j++) { System.out.print(++num); System.out.print(--num);
			 * } System.out.println();
			 */
		}

	}

}

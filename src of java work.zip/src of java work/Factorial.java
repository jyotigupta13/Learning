import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		int i,fact=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the numer for factorial");
		int n=sc.nextInt();
        for(i=2;i<=n;i++) {
        	fact=fact*i;
        	
        }
        System.out.println("factorial of number = " + fact);
	}

}

import java.util.Scanner;
public class RevDigit {

	public static void main(String[] args) {
		int number,rev=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number to reverse");
		int n=sc.nextInt();
	    int temp=n;
		while(n!=0){
		number=n%10;
		rev=(rev*10)+number;
		n=n/10;
		}
		System.out.println(temp + " of reverse no is : " + rev);
	}

}


public class Piramid18 {

	public static void main(String[] args) {
		int i,j,k;
		for(i=1;i<=7;i++) {
			for(j=1;j<i;j++) {
				System.out.print(" ");
			}
			for(k=i;k<=7;k++) {
				System.out.print(k);
			}
			
			System.out.println();
		}
			for(i=6;i>=1;i--) {
				for(j=1;j<=i-1;j++) {
					System.out.print(" ");
				}
				for(k=i;k<=7;k++) {
					System.out.print(k);
				}
				System.out.println();
			}
		

	}

}

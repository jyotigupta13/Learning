import java.util.Scanner;
public class LinearSearch {

	public static void main(String[] args) {
		int i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of element in array : ");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("Enter element : ");
        for(i=0;i<n;i++) {
        	a[i]=sc.nextInt();
        }
        System.out.println("Enter element that you want : ");
        int search=sc.nextInt();
        for(i=0;i<n;i++) {
        	 if(a[i]==search){
        		 System.out.println(search + " element is found at " + (i+1) + " position");
        		 break;
        	 }
			/*
			 * else { System.out.println("element not found in this array"); break; }
			 */
        		 
        }
        if(i==n) {
        	System.out.println("not present");
        }
	}

}

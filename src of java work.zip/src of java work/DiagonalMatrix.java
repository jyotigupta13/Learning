import java.util.Scanner;

public class DiagonalMatrix {

	public static void main(String[] args) {
		int i, j, left = 0,right=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of an matrix : ");
		int n = sc.nextInt();
		//int m = sc.nextInt();
		int a[][] = new int[n][n];
		System.out.println("enter element : ");
		for (i = 0; i < n; i++) {
			for (j = 0; j < n; j++) {
				a[i][j] = sc.nextInt();
				
			}
			
		}
		System.out.println("Element of matrix : ");
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println();
		for (i = 0; i < n; i++) {
			for (j = 0; j < n; j++) {
                if (i == j) {
                 	left = left + a[i][j];
				}
                  if(i+j==n-1) {
                	right=right + a[i][j];
                }
			}
			
		}
		System.out.println("sum of diagonal left : " + left);
		System.out.println("sum of diagonal right : " + right);
		
	}

}

import java.util.Scanner;
public class Length {

	public static void main(String[] args) {
		 double hypo;
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter leg");
		 double leg=sc.nextInt();
		 System.out.println("Enter base");
		 double base=sc.nextInt();
         hypo=Math.sqrt(Math.pow(leg,2)+Math.pow(base,2));
         System.out.println("length of hypotenious" + hypo);
         System.out.println("hypo" + Math.hypot(2,2));
	}

}

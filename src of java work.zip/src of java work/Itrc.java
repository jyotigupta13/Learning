class Student{
	int age;
	String name;
	int rollno;
	Student(int age,String name,int rollno){
		this.age=age;
		this.name=name;
		this.rollno=rollno;
	}
	
}


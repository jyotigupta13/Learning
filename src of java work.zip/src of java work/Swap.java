import java.util.Scanner;
public class Swap {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		String a=sc.nextLine();
		String b=sc.nextLine();
		System.out.println("Before swap\n a=" + a);
		System.out.println(" b=" + b);
		int x=Integer.parseInt(a);
		int y=Integer.parseInt(b);
		x=x+y;
		y=x-y;
        x=x-y;
        System.out.println("After swapping\n a=" + x);
        System.out.println(" b=" + y);
		
		
		

	}

}

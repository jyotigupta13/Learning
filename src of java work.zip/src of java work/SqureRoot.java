import java.util.Scanner;
public class SqureRoot {

	public static void main(String[] args) {
		double x=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
			x=0.5*(x+n/x);
			
			
		}
		System.out.println("Square root of " + n + " is " + x);

	}

}

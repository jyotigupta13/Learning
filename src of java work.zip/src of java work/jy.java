
public class jy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int a=2,b=3;
       System.out.println("Before swap\n a = " + a + "\n b = " + b);
       a=a+b;
       b=a-b;
       a=a-b;
       System.out.println("After swap\n a = " + a + "\n b = " + b );
	}

}

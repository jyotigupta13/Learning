import java.util.Scanner;
public class EvenPrint {

	public static void main(String[] args) {
		int count;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
        int n=sc.nextInt();
        for(int i=1;i<=n;i++) {
        	//for(int j=1;j<=n;j++)
        	if(i%2!=0) {
        		 count=1;
        	}
        	else {
        		count=0;
        	}
        	if(count==1) {
        		System.out.print(i + " ");
        	}
        	
        }
	}

}

import java.util.Scanner;
public class Sum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first digit");
		int a=sc.nextInt();
        System.out.println("enter second digit");
	    int b=sc.nextInt();
	    int sum=a+b;
	    System.out.println("sum of digit = " + sum);
	}

}

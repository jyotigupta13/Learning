import java.util.Scanner;
public class RecursionFact {

	public static void main(String[] args) {
		int fact=1,i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		RecursionFact s=new RecursionFact();
	    s.jy(n);
		
	}

	    void jy(int n) {
		int fact=1;
		for(int i=1;i<=n;i++) {
		    fact=fact*i;
		     }
		    System.out.println("Factorial is : " + fact);
		
	}

}

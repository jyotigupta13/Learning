import java.util.Scanner;
public class ArmstrongNo {

	public static void main(String[] args) {
		int i,sum=0,a;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no:");
		int n=sc.nextInt();
		int temp=n;
		while(n>0) {
			a=n%10;
			sum=sum+(a*a*a);
			n=n/10;
		}
		if(temp==sum) {
		System.out.println("armstrong");
		}
		else {
			System.out.println("not armstrong");
		}

	}

}

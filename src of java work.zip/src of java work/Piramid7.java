
public class Piramid7 {

	public static void main(String[] args) {
		int i,j=0,k,row=5;
		for(i=1;i<=5;i++) {
			for(j=row-1;j>=i;j--) {
				System.out.print(" ");
			}
			for(k=1;k<=i;k++) {
				System.out.print("*");
			}
			for(k=1;k<i;k++) {
				System.out.print("*");
			}
			System.out.println();
			
		}

	}

}

import java.util.Scanner;
public class PalindromRec {
static int num,sum=0,palin,n;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		 n=sc.nextInt();
		int original=n;
		int temp=palin(n);
		if(original==sum) {
			System.out.println("palindrom");
		}
		else {
			System.out.println("not palindrom");
		}

	}
		
		static int palin(int n) {
		if(n==0) {
			return n;
		}
			 num=n%10;
			sum=sum*10+num;
			n=n/10;
			return palin(n);
		  }
		
		

}

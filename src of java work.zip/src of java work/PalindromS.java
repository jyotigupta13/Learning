import java.util.Scanner;
public class PalindromS {

	public static void main(String[] args) {
		       int i;
				String temp,rev="";
				Scanner sc=new Scanner(System.in);
				System.out.println("enter string to check palindrom");
				String s=sc.nextLine();
		        int length=s.length();
		        for(i=length-1; i>=0; i--) {
		        	rev=rev + s.charAt(i);
		        }
		        if(s.equals(rev)) {
		        	System.out.println("palindrom");
		        }
		        else {
		        	System.out.println("not palindrom");
		        }

	}

}

import java.util.Scanner;
public class ConcatString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter s1 string : ");
		String s1=sc.nextLine();
		System.out.println("Enter s2 string : ");
		String s2=sc.nextLine();
		String s3=s1.concat(s2);
		System.out.println(s3);
		System.out.println(s1+s2);
		String s4="Vandu";
        System.out.println(s2+s4);

	}

	

}

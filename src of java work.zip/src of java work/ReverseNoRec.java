import java.util.Scanner;
public class ReverseNoRec {
static int i,n;
static int res=0;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number : ");
		int num=sc.nextInt();
		System.out.println("Number in reverse order : ");
		Reverse(num);
		//System.out.print(rev);
		
	}
	static void Reverse(int num) {
		if(num<10) {
			System.out.print(num);
			return;
		}
		System.out.print(num%10);
		Reverse(num/10);	
	}

}


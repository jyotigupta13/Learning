import java.util.Scanner;
public class MultiplicationMatrix {

	public static void main(String[] args) {
		int i,j,k;
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the size of matrix : ");
	    int n=sc.nextInt();
	   // int col=sc.nextInt();
	    int a[][]=new int[n][n];
	    int b[][]=new int[n][n];
	    int mul[][]=new int[n][n];
	    System.out.println("Enter element of a matrix");
        for(i=0;i<n;i++) {
        	for(j=0;j<n;j++) {
        		a[i][j]=sc.nextInt();
        	}
        }
        System.out.println("Enter element of b matrix");
        for(i=0;i<n;i++) {
        	for(j=0;j<n;j++) {
        		b[i][j]=sc.nextInt();
        	}
        }
        System.out.println("matrix of a is : ");
        for(i=0;i<n;i++) {
        	for(j=0;j<n;j++) {
        System.out.print(a[i][j] + " ");
        	}
        	System.out.println();
        }
        System.out.println("matrix of b is : ");
        for(i=0;i<n;i++) {
        	for(j=0;j<n;j++) {
        System.out.print(b[i][j] + " ");
        	}
           System.out.println();
        }
        
        for(i=0;i<n;i++) {
        	for(j=0;j<n;j++) {
        		mul[i][j]=0;
        		for(k=0;k<n;k++) {
        			mul[i][j]=mul[i][j]+(a[i][k] * b[k][j]);
        		}
        	}
        }
        System.out.println("multiplication of this matrix are : ");
        for(i=0;i<n;i++) {
        for(j=0;j<n;j++) {	
        
        System.out.print(mul[i][j] + " ");
          }
        System.out.println();
        }
	}

}

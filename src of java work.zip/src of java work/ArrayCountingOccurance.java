import java.util.Scanner;
public class ArrayCountingOccurance {

	public static void main(String[] args) {
		int i;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		int a[]=new int[10];
		while(n>0) {
			 int rem=n%10;
			 a[rem]++;
			 n=n/10;
		}
		System.out.println("Element       |      Frequency");
		for(i=0;i<a.length;i++) {
			int count=a[i];
			if(a[i]!=0) {
				System.out.print(i + "\t" + "\t" + count);
			}
			System.out.println();
		}

	}

}

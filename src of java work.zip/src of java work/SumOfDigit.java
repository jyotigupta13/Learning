import java.util.Scanner;
public class SumOfDigit {

	public static void main(String[] args) {
		int a,i,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number : ");
		int n=sc.nextInt();
		while(n>0) {
         a=n%10;
         sum=sum+a;
		 n=n/10;
		 
		}
		System.out.println("sum of digit : " + sum);



	

	}

}

import java.util.Scanner;
public class FactRec {
	static int fact=1;
	static int fact(int n) {
		int output;
		if(n==1) {
			return 1;
		}
		else
			output=n*fact(n-1);
		return output;
	}
    public static void main(String[] ar) {
    	 Scanner sc=new Scanner(System.in);
    	System.out.println("Enter number : ");
    	 int n=sc.nextInt();
		FactRec s=new FactRec();
		int factorial=fact(n);
		//s.fact(n);
		System.out.println("factorial is : " + factorial);
	}
   
}

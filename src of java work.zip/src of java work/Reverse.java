import java.util.Scanner;
public class Reverse {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		System.out.println("enter your string = " + name);
		String s=new StringBuffer(name).reverse().toString();
		System.out.println("reverse string = " + s);

	}

}
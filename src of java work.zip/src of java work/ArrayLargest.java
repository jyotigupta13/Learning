import java.util.Scanner;
public class ArrayLargest {

	public static void main(String[] args) {
		int i,max;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of element in array : ");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("Enter element : ");
       for(i=0;i<n;i++) {
    	   a[i]=sc.nextInt();
       }
       max=a[0];
       for(i=1;i<n;i++) {
       if(max < a[i]) {
    	   max=a[i];
       }
       
       }
       System.out.println("maximum : " + max);
	}

}

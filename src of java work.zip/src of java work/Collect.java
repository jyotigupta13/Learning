import java.util.*;
public class Collect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    List<String> list1=new ArrayList<String>();
     list1.add("jyoti");
     list1.add("vandana");
     list1.add("Amit");
     Iterator itr=list1.iterator();
     while(itr.hasNext()) {
    	 System.out.println(itr.next());
    			 
     }
     System.out.println(list1);
     
	}

}

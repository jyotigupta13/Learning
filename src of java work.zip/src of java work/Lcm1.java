import java.util.Scanner;
public class Lcm1 {

	public static void main(String[] args) {
		int lcm,a,b;
	  Scanner sc=new Scanner(System.in);
	  System.out.print("enter first number\n");
	   a=sc.nextInt();
	  System.out.print("enter second number\n");
       b=sc.nextInt();
      
      lcm=(a>b) ? a:b;
     
     while(true) {
    	 if(lcm % a == 0 && lcm%b==0) {
    		System.out.printf("lcm of %d and %d is %d",a,b,lcm);	
    		break;
    	     }
    	++lcm;
    	
     }
	}

}

import java.util.Scanner;
public class Lcm2 {

	public static void main(String[] args) {
		int i,gcd=1,lcm;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first no");
		int a=sc.nextInt();
		System.out.println("Enter second no");
		int b=sc.nextInt();
		
	   for(i=1;i<=a && i<=b;++i) {
		   if(a%i==0 && b%i==0) 
			   gcd=i;
		 
		   
	   }
	   System.out.printf("gcd of %d and %d is : %d \n ",a,b,gcd); 
	   
		lcm=(a*b)/gcd;
		System.out.printf("lcm of %d and %d is : %d ",a,b,lcm);
	   
		
						

	}

}


public class Piramid9 {

	public static void main(String[] args) {
		int i,j,k,row=5;
		for(i=row;i>=1;--i) {
			for(j=i;j<=row-1;j++) {
				System.out.print(" ");
			}
			for(k=1;k<=i;++k) {
				System.out.print("*");
				
			}
			for(k=1;k<i;++k) {
				System.out.print("*");
			}
			
			
			
			System.out.println();
		}

	}

}

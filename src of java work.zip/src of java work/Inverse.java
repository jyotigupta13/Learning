import java.util.Scanner;
public class Inverse {

	public static void main(String[] args) {
		int i,j,det,inverse,temp;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter element of matrix row wise : ");
		int a[][]=new int[2][2];
	    for(i=0;i<2;i++) {
	    	for(j=0;j<2;j++) {
	    		a[i][j]=sc.nextInt();
	    	}
	    }
	    det=(a[0][0]*a[1][1] - a[0][1]*a[1][0]);
	    
	    temp=a[0][0];
	    a[0][0]=a[1][1];
	    a[1][1]=temp;
	    
	    a[0][1]=-a[0][1];
	    a[1][0]=-a[1][0];
	    
	    System.out.println("inverse are : ");
	    for(i=0;i<2;i++) {
	    	for(j=0;j<2;j++) {
	    		 System.out.print(a[i][j]/det + "\t");
	    	}
	    	System.out.println();
	    }
	   
	   
	    

	}

}

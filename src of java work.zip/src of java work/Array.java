
public class Array {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
      int a[]= {2,3,4,5,6,7};
      int b[]= {4,5,6,2,7,5};
      System.out.println("2 no. array of a=" + a[2]);
      System.out.println("4 no. array of b=" + b[4]);
	}

}
